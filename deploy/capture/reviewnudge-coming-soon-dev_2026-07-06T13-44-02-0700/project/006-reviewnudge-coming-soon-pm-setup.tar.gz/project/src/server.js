import crypto from 'node:crypto';
import http from 'node:http';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { Pool } from 'pg';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDirectory = path.join(__dirname, '..', 'public');

const config = {
  port: Number(process.env.PORT || 3080),
  databaseUrl: process.env.DATABASE_URL || 'postgresql://reviewnudge_app:reviewnudge_dev_password@db:5432/reviewnudge?sslmode=disable',
  stack: process.env.STACK || 'reviewnudge-coming-soon-dev',
  abuseSalt: process.env.ABUSE_IDENTIFIER_SALT || 'dev-only-reviewnudge-waitlist-salt-change-me'
};

const pool = new Pool({ connectionString: config.databaseUrl });

const mimeTypes = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.svg', 'image/svg+xml; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.webp', 'image/webp'],
  ['.ico', 'image/x-icon']
]);

function log(level, message, fields = {}) {
  const parts = [new Date().toISOString(), level, message];
  for (const [key, value] of Object.entries(fields)) {
    parts.push(`${key}=${String(value).replace(/\s+/g, '_')}`);
  }
  console.log(parts.join(' '));
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store'
  });
  res.end(body);
}

function sendText(res, status, text) {
  res.writeHead(status, {
    'content-type': 'text/plain; charset=utf-8',
    'content-length': Buffer.byteLength(text),
    'cache-control': 'no-store'
  });
  res.end(text);
}

function cleanText(value, maxLength = 200) {
  return String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, maxLength);
}

function cleanEmail(value) {
  const email = cleanText(value, 254).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : '';
}

function requestIp(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket.remoteAddress || 'unknown';
}

function hashIdentifier(value) {
  return crypto.createHash('sha256').update(`${config.abuseSalt}:${value}`).digest('hex');
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 16_384) {
      throw Object.assign(new Error('Request body too large.'), { status: 413 });
    }
    chunks.push(chunk);
  }

  if (chunks.length === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw Object.assign(new Error('Invalid JSON request body.'), { status: 400 });
  }
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS waitlist_signups (
      id BIGSERIAL PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      source TEXT NOT NULL DEFAULT 'coming-soon',
      ip_hash TEXT,
      user_agent TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
}

async function handleWaitlist(req, res) {
  const body = await readJson(req);
  const email = cleanEmail(body.email);
  const source = cleanText(body.source || 'coming-soon', 80) || 'coming-soon';

  if (!email) {
    return sendJson(res, 400, { ok: false, error: 'Please enter a valid email address.' });
  }

  const ipHash = hashIdentifier(requestIp(req));
  const userAgent = cleanText(req.headers['user-agent'] || '', 500);

  await pool.query(
    `INSERT INTO waitlist_signups (email, source, ip_hash, user_agent)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (email) DO UPDATE
       SET source = EXCLUDED.source,
           ip_hash = EXCLUDED.ip_hash,
           user_agent = EXCLUDED.user_agent,
           updated_at = now()`,
    [email, source, ipHash, userAgent]
  );

  log('INFO', 'waitlist signup captured', { email, source, stack: config.stack });
  return sendJson(res, 200, { ok: true, message: "You're on the list." });
}

async function serveStatic(req, res) {
  const url = new URL(req.url || '/', 'http://localhost');
  let pathname = decodeURIComponent(url.pathname);

  if (pathname === '/' || pathname === '/index.html') pathname = '/index.html';

  if (!/^\/[a-zA-Z0-9._\-\/]+$/.test(pathname) || pathname.includes('..')) {
    return sendText(res, 404, 'Not found');
  }

  const filePath = path.join(publicDirectory, pathname);
  if (!filePath.startsWith(publicDirectory)) {
    return sendText(res, 404, 'Not found');
  }

  try {
    const data = await readFile(filePath);
    const type = mimeTypes.get(path.extname(filePath)) || 'application/octet-stream';
    res.writeHead(200, {
      'content-type': type,
      'content-length': data.length,
      'cache-control': type.includes('text/html') ? 'no-store' : 'public, max-age=300'
    });
    res.end(data);
  } catch {
    sendText(res, 404, 'Not found');
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://localhost');

    if (req.method === 'GET' && (url.pathname === '/livez' || url.pathname === '/healthz')) {
      return sendJson(res, 200, { ok: true, stack: config.stack });
    }

    if (req.method === 'POST' && url.pathname === '/api/waitlist') {
      return handleWaitlist(req, res);
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      return serveStatic(req, res);
    }

    res.setHeader('allow', 'GET, HEAD, POST');
    return sendText(res, 405, 'Method not allowed');
  } catch (error) {
    const status = Number(error.status || 500);
    log(status >= 500 ? 'ERROR' : 'WARN', error.message || 'request failed', { status });
    return sendJson(res, status, { ok: false, error: status >= 500 ? 'Something went wrong.' : error.message });
  }
});

process.on('SIGTERM', () => {
  server.close(async () => {
    await pool.end();
    process.exit(0);
  });
});

await ensureSchema();
server.listen(config.port, '0.0.0.0', () => {
  log('INFO', 'ReviewNudge coming soon server listening', { port: config.port, stack: config.stack });
});
