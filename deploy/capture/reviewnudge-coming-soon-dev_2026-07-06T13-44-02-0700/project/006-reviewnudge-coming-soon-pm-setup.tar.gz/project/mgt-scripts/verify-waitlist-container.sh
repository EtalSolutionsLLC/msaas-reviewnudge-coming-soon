#!/usr/bin/env bash
set -euo pipefail

base_url="${WAITLIST_BASE_URL:-http://localhost:${WAITLIST_HTTP_PORT:-3080}}"
email="${WAITLIST_TEST_EMAIL:-container-smoke-$(date +%s)@example.test}"

for _ in $(seq 1 30); do
  if curl --fail --silent --show-error "$base_url/livez" >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

curl --fail --silent --show-error \
  --header 'Content-Type: application/json' \
  --data "{\"email\":\"${email}\",\"source\":\"container-smoke\"}" \
  "$base_url/api/waitlist" >/dev/null

echo "Waitlist container smoke test passed: ${email}"
