# Build 006 — ReviewNudge Coming Soon Waitlist

## Changes

- Renamed the Coming Soon HTML entrypoint to `public/index.html`.
- Promoted the waitlist container compose file to the default `docker-compose.yml`.
- Removed the manual compose run path from the handoff; `pm-setup` is the expected runner.
- Included a small Node/PostgreSQL waitlist endpoint at `POST /api/waitlist`.
- Added a smoke verification script that assumes the app was started by `pm-setup`.

## Operator command

```bash
pm-extract-files-from-tar 006-reviewnudge-coming-soon-pm-setup.tar.gz .
pm-setup
```
