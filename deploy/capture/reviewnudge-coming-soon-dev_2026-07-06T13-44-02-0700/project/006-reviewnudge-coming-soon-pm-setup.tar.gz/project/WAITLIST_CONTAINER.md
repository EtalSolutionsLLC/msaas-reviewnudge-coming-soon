# ReviewNudge Coming Soon Waitlist Container

This package makes the Coming Soon waitlist the default containerized app.

## Run

```bash
pm-extract-files-from-tar 006-reviewnudge-coming-soon-pm-setup.tar.gz .
pm-setup
```

Open:

```text
http://localhost:3080/
```

The waitlist form posts to:

```text
POST /api/waitlist
```

Waitlist emails are stored in PostgreSQL in:

```text
waitlist_signups
```

## Verify

```bash
./mgt-scripts/verify-waitlist-container.sh
```
