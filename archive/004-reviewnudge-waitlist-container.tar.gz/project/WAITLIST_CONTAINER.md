# ReviewNudge Waitlist Container

This adds a standalone container path for the Coming Soon waitlist slice.

## Quick run

```bash
docker compose --file docker-compose.waitlist.yml up --build
```

Open:

```text
http://localhost:3080/coming-soon.html
```

The waitlist form posts to:

```text
POST /api/waitlist
```

Data is stored in PostgreSQL in:

```text
public.waitlist_signups
```

## Smoke test

```bash
./mgt-scripts/verify-waitlist-container.sh
```

## Notes

This compose file is intentionally standalone. It does not require the shared Traefik proxy network, so the waitlist slice can be reviewed in a plain local container environment. The normal project `docker-compose.yml` and `pm-setup` path remain the canonical development path.
