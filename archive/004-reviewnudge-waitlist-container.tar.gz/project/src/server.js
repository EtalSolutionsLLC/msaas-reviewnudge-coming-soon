import crypto from 'node:crypto';
import { createPmLogger } from './pm-logger.js';

const logger = createPmLogger('reviewnudge-web');
import http from 'node:http';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { getConfig, workspaceTokenUrl, workspaceUrl } from './config.js';
import { datastore as defaultDatastore } from './datastore/index.js';
import {
  appendAccountHint,
  createSession,
  currentTenant,
  destroySession,
  hashPassword,
  loadSession,
  tenantFromSession,
  verifyPassword
} from './auth.js';
import { createMessenger, transactionalHtmlMessage } from './messenger.js';
import { defaultTemplate, renderTemplate } from './templates.js';
import { normalizeHostname, normalizeTenantSlug, requestHost } from './tenant-resolver.js';
import { billingAccess } from './billing.js';
import { sealToken } from './secure-token.js';
import { verifyInternalRequest } from './internal-signature.js';
import { decryptSlackSecret, encryptSlackSecret, exchangeSlackOAuthCode, notifySlackOfReview, postSlackWebhook, slackConnectionView, slackInstallUrl } from './slack.js';
import { matchReviewToCustomers } from './review-matcher.js';
import { customerLimitForTenant, hashAbuseIdentifier, recipientDomain, sendLimitsForTenant, validateReviewDestination } from './abuse-controls.js';
import { verifyTurnstile } from './turnstile.js';
import { content } from './content.js';
import { generateRegistrationOptions, verifyRegistrationResponse, generateAuthenticationOptions, verifyAuthenticationResponse } from '@simplewebauthn/server';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDirectory = path.join(__dirname, '..', 'public');
const publicRoutes = new Set(['/', '/setup', '/login', '/reset-password', '/verify-email', '/privacy', '/terms', '/acceptable-use', '/billing', '/security', '/ai-transparency', '/cookies', '/communication-compliance']);
const staticExactPaths = new Set([
  '/app.js',
  '/auth-hint.js',
  '/content.generated.js',
  '/styles.css',
  '/coming-soon.html'
]);
const staticPrefixes = ['/assets/', '/styles/', '/theme/', '/legal/'];
const mimeTypes = new Map([
  ['.css', 'text/css; charset=utf-8'], ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'], ['.json', 'application/json; charset=utf-8'],
  ['.svg', 'image/svg+xml; charset=utf-8'], ['.png', 'image/png'], ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'], ['.webp', 'image/webp'], ['.ico', 'image/x-icon']
]);

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function cleanText(value, maxLength = 200) {
  return String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, maxLength);
}

function cleanEmail(value) {
  const email = cleanText(value, 254).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : '';
}

function isActiveCustomerEmailConflict(error) {
  return error?.code === '23505' && error?.constraint === 'uq_customers_active_email';
}

async function customerWrite(operation) {
  try {
    return await operation();
  } catch (error) {
    if (isActiveCustomerEmailConflict(error)) {
      throw new HttpError(409, content('errors.customerEmailConflict', {}, 'A customer with that email address is already active in this workspace.'));
    }
    throw error;
  }
}

function cleanUrl(value) {
  try {
    const url = new URL(String(value || '').trim());
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : '';
  } catch { return ''; }
}

function clientIp(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket?.remoteAddress || 'unknown';
}

const emailThemeCodes = new Set(['light', 'navy', 'warm', 'dark']);
const emailLogoMimeTypes = new Set(['image/png', 'image/jpeg', 'image/webp']);

function parseEmailLogoDataUrl(value) {
  if (value === null) return { changed: true, data: null, mime: null };
  if (value === undefined) return { changed: false, data: null, mime: null };
  const match = String(value).match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match || !emailLogoMimeTypes.has(match[1])) throw new HttpError(400, content('errors.logoType', {}, 'Choose a PNG, JPG, or WebP logo.'));
  const data = Buffer.from(match[2], 'base64');
  if (!data.length || data.length > 131072) throw new HttpError(400, content('errors.logoSize', {}, 'Keep the logo at 128 KB or smaller.'));
  return { changed: true, data, mime: match[1] };
}

function publicSettings(settings, tenant, config) {
  if (!settings) return settings;
  const { email_logo_data: _logoData, ...safe } = settings;
  return {
    ...safe,
    has_email_logo: Boolean(settings.email_logo_data && settings.email_logo_mime),
    email_logo_url: settings.email_logo_data ? `${config.appBaseUrl}/api/branding/${encodeURIComponent(tenant.slug)}/logo?v=${encodeURIComponent(String(settings.updated_at || '1'))}` : null
  };
}

function tokenHash(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function emailHash(value) { return crypto.createHash('sha256').update(String(value || '').trim().toLowerCase()).digest('hex'); }

async function enforceRateLimit(datastore, config, { scope, identifier, windowSeconds, limit }) {
  if (!config.abuse.enabled || typeof datastore.consumeRateLimit !== 'function') return;
  const result = await datastore.consumeRateLimit({
    scope,
    identifierHash: hashAbuseIdentifier(identifier, config.abuse.identifierSalt),
    windowSeconds,
    limit
  });
  if (!result.allowed) throw new HttpError(429, content('errors.rateLimit', { time: new Date(result.resetAt).toLocaleTimeString() }, `You’ve tried that a few times. Try again after ${new Date(result.resetAt).toLocaleTimeString()}.`));
}

async function enforceAuthenticatedAction(req, datastore, config, action, limit) {
  if (!req.session?.user_id) return;
  const dimensions = [
    ['workspace', req.session.tenant_id],
    ['user', req.session.user_id],
    ['session', req.session.session_id],
    ['ip', clientIp(req)]
  ];
  for (const [dimension, identifier] of dimensions) {
    if (!identifier) continue;
    await enforceRateLimit(datastore, config, {
      scope: `${action}-${dimension}`,
      identifier,
      windowSeconds: 3600,
      limit
    });
  }
}

async function sendVerificationEmail({ messenger, config, account, token }) {
  if (typeof messenger.sendEmail !== 'function') return { skipped: true };
  const verifyUrl = workspaceTokenUrl(config, account.slug, 'verify_token', token);
  const message = content('emails.verification.message', { hours: config.abuse.emailVerificationTtlHours }, `Verify this email address to turn on sending for your ReviewNudge workspace. The link expires in ${config.abuse.emailVerificationTtlHours} hours and works once.`);
  return messenger.sendEmail({
    to: account.email,
    subject: content('emails.verification.subject', {}, 'Verify your ReviewNudge email'),
    text: `${message}

${content('emails.verification.fallbackLabel', {}, 'Verify email:')} ${verifyUrl}`,
    html: transactionalHtmlMessage({
      title: content('emails.verification.title', {}, 'One quick email check'),
      message,
      actionUrl: verifyUrl,
      actionLabel: content('emails.verification.action', {}, 'Verify email'),
      privacyUrl: config.privacyPolicyUrl,
      supportEmail: config.supportEmail,
      footerNote: content('emails.verification.footer', {}, 'You received this because a ReviewNudge workspace was created with this address.')
    }),
    tags: [
      { name: 'product', value: 'reviewnudge' },
      { name: 'message_type', value: 'email_verification' }
    ]
  });
}

function effectiveConfig(config) {
  return {
    ...config,
    policyVersion: config.policyVersion || 'placeholder-2026-07-03',
    foundingFeedbackEmail: config.foundingFeedbackEmail || '',
    privacyPolicyUrl: config.privacyPolicyUrl || 'https://public.etal.solutions/docs/et-al-solutions-llc/et-al-solutions-llc-privacy-policy.html',
    billing: config.billing || {
      paymentAppUrl: 'https://payment.etal.solutions', checkoutTokenKey: '', checkoutTokenTtlMinutes: 60,
      internalSecret: '', tokenIssuer: 'reviewnudge', tokenAudience: 'payment.etal.solutions',
      productCode: 'reviewnudge_monthly', foundingLimit: 25, foundingAmountCents: 995,
      standardAmountCents: 2495, currency: 'usd', trialDays: 15, warningDays: 5, graceDays: 7
    },
    jobs: {
      batchSize: 100,
      emailerSyncIntervalHours: 6,
      emailerSyncRetentionDays: 30,
      emailerSyncBatchSize: 100,
      ...(config.jobs || {})
    },
    turnstile: {
      enabled: false, siteKey: '', secretKey: '',
      verifyUrl: 'https://challenges.cloudflare.com/turnstile/v0/siteverify', timeoutMs: 10000,
      ...(config.turnstile || {})
    },
    abuse: {
      enabled: true, outboundEmailEnabled: true, identifierSalt: config.stack || 'reviewnudge',
      emailVerificationTtlHours: 24, signupIpHourlyLimit: 10, signupEmailDailyLimit: 3,
      loginIpHourlyLimit: 60, loginEmailHourlyLimit: 20, verificationResendHourlyLimit: 3,
      passwordResetHourlyLimit: 3, authenticatedMutationHourlyLimit: 120, sendActionHourlyLimit: 60, billingCheckoutHourlyLimit: 10,
      trialHourlyLimit: 5, trialDailyLimit: 20, trialTotalLimit: 50,
      paidNewHourlyLimit: 25, paidNewDailyLimit: 100,
      establishedHourlyLimit: 100, establishedDailyLimit: 1000, establishedAfterDays: 30,
      recipientCooldownHours: 24, pendingCustomerLimit: 5, trialCustomerLimit: 25, activeCustomerLimit: 2500,
      bounceRateMinimumMessages: 20, bounceRateRestrictionPercent: 15, blockedAttemptRestrictionThreshold: 10,
      blockedSignupEmailDomains: [],
      blockedShortenerDomains: ['bit.ly','tinyurl.com','t.co','goo.gl','ow.ly','rebrand.ly','cutt.ly'],
      ...(config.abuse || {})
    },
    reviews: config.reviews || { eventSecret: '' },
    slack: {
      enabled: false, clientId: '', clientSecret: '', tokenEncryptionKey: '',
      redirectUrl: `${config.appBaseUrl}/api/slack/oauth/callback`,
      scopes: ['incoming-webhook','chat:write'], oauthStateTtlMinutes: 10, timeoutMs: 10000,
      ...(config.slack || {})
    }
  };
}

function setSecurityHeaders(res) {
  res.setHeader('Content-Security-Policy', "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; img-src 'self' data: https://challenges.cloudflare.com; object-src 'none'; script-src 'self' https://challenges.cloudflare.com; frame-src https://challenges.cloudflare.com; connect-src 'self' https://challenges.cloudflare.com; style-src 'self' 'unsafe-inline'");
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
}

function sendJson(res, status, payload) {
  if (res.writableEnded) return;
  const body = JSON.stringify(payload);
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Length', Buffer.byteLength(body));
  res.end(body);
}

function sendText(res, status, value, contentType = 'text/plain; charset=utf-8') {
  if (res.writableEnded) return;
  const body = String(value);
  res.statusCode = status;
  res.setHeader('Content-Type', contentType);
  res.setHeader('Content-Length', Buffer.byteLength(body));
  res.end(body);
}

function redirect(res, location, status = 302) {
  res.statusCode = status; res.setHeader('Location', location); res.setHeader('Content-Length', '0'); res.end();
}

async function readRequestBody(req, maxBytes = 262_144) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return { raw: '', json: {} };
  let size = 0; const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new HttpError(413, content('errors.bodyLarge', {}, 'That request is a little too large.'));
    chunks.push(chunk);
  }
  const raw = chunks.length ? Buffer.concat(chunks).toString('utf8') : '';
  if (!raw) return { raw, json: {} };
  try { return { raw, json: JSON.parse(raw) }; }
  catch { throw new HttpError(400, content('errors.jsonInvalid', {}, 'Something in that request was not formatted correctly.')); }
}

function isStaticPath(pathname) { return staticExactPaths.has(pathname) || staticPrefixes.some(prefix => pathname.startsWith(prefix)); }

async function serveStatic(pathname, res, config) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { throw new HttpError(400, content('errors.invalidPath', {}, 'That link does not look right.')); }
  const target = path.resolve(publicDirectory, `.${decoded}`);
  if (!target.startsWith(`${publicDirectory}${path.sep}`)) throw new HttpError(404, content('errors.notFound', {}, 'We could not find that.'));
  try {
    const body = await readFile(target);
    res.statusCode = 200;
    res.setHeader('Content-Type', mimeTypes.get(path.extname(target).toLowerCase()) || 'application/octet-stream');
    res.setHeader('Content-Length', body.length);
    res.setHeader('Cache-Control', config.cmEnv === 'prd' ? 'public, max-age=3600' : 'no-store');
    res.end(body);
  } catch (error) {
    if (error.code === 'ENOENT' || error.code === 'EISDIR') throw new HttpError(404, content('errors.notFound', {}, 'We could not find that.'));
    throw error;
  }
}

async function servePublicPage(res) {
  const body = await readFile(path.join(publicDirectory, 'index.html'));
  res.statusCode = 200; res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Length', body.length); res.setHeader('Cache-Control', 'no-store'); res.end(body);
}

function sendBrandedError(res, status, message, config) {
  const safe = String(message || content('errors.notFound', {}, 'We could not find that.')).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c]);
  const title = status === 404 ? content('errors.page404Title', {}, 'That workspace wandered off') : content('errors.pageTitle', {}, 'ReviewNudge hit a small snag');
  const body = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} · ReviewNudge</title><link rel="stylesheet" href="/theme/default.css"><link rel="stylesheet" href="/styles.css?v=068"></head><body><div class="app-frame"><header class="topbar" data-pm-sticky-header><a class="product-lockup" href="${config.appBaseUrl}"><img class="product-mark" src="/assets/reviewnudge-mark.svg" alt="" width="42" height="42"><span class="product-identity"><strong>ReviewNudge™</strong><small>Built on Portmason™</small></span></a></header><main class="shell error-shell"><section class="public-page pm-viewport-target" data-pm-viewport-target><div class="public-page-content"><header class="public-page-header compact"><p class="eyebrow">${content('errors.pageEyebrow', {}, 'Well, that took a wrong turn')}</p><h1>${title}</h1><p class="lede">${safe}</p></header><div class="prose-card"><p>${content('errors.pageBody', {}, 'Check the link, head back to ReviewNudge, or ask us for a hand.')}</p><div class="hero-actions"><a class="button button-primary" href="${config.appBaseUrl}">${content('errors.pageHome', {}, 'Back to ReviewNudge')}</a><a class="button button-secondary" href="${config.appBaseUrl}/#support">${content('errors.pageSupport', {}, 'Get help')}</a></div></div></div></section></main></div><script type="module">import{getViewportFrame}from'/assets/pm-viewport-navigation.js';getViewportFrame({headerSelector:'[data-pm-sticky-header]'});</script></body></html>`;
  sendText(res, status, body, 'text/html; charset=utf-8');
}

function requirePublicHost(req) { if (!req.requestHost) throw new HttpError(404, content('errors.publicHost', {}, 'Open this page from the main ReviewNudge address.')); }
function requireTenantHost(req) { if (!req.tenantContext) throw new HttpError(401, content('errors.authRequired', {}, 'Please sign in to continue.')); }
function requireAuth(req) {
  if (!req.session?.user_id || !req.tenantContext?.id) throw new HttpError(401, content('errors.authRequired', {}, 'Please sign in to continue.'));
  if (req.session.tenant_id !== req.tenantContext.id) throw new HttpError(403, content('errors.workspaceRequired', {}, 'Please sign in again and try once more.'));
}
function requireRole(req, ...allowed) { requireAuth(req); if (!allowed.includes(req.session?.role)) throw new HttpError(403, content('errors.role', {}, 'This account does not have permission to do that.')); }
function requireWritable(req, config) {
  requireAuth(req);
  const access = billingAccess(currentTenant(req), config);
  if (!access.canWrite) throw new HttpError(402, content('errors.subscription', {}, 'Choose a plan before changing workspace data or sending review requests.'));
  return access;
}

function enforceSameOrigin(req) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return;
  const origin = req.headers.origin;
  if (!origin) return;
  try {
    if (normalizeHostname(new URL(origin).host) !== req.requestHost) throw new HttpError(403, content('errors.origin', {}, 'That request could not be verified. Refresh the page and try again.'));
  } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(403, content('errors.origin', {}, 'That request could not be verified. Refresh the page and try again.'));
  }
}

async function resolveRequestContext(req, _datastore, config, pathname) {
  const host = requestHost(req); req.requestHost = host;
  if (host !== config.appHost) throw new HttpError(404, content('errors.unknownHost', {}, 'We could not find that ReviewNudge address.'));
  req.requestContext = 'public';
  req.routePath = pathname;
}

function publicContextResponse(req, config) {
  const tenant = req.tenantContext;
  const feedbackEligible = Boolean(
    req.session?.user_id
    && tenant?.pricing_tier === 'founding'
    && config.foundingFeedbackEmail
  );
  const feedbackHref = feedbackEligible
    ? `mailto:${config.foundingFeedbackEmail}?subject=${encodeURIComponent('ReviewNudge Founding 25 feedback')}`
    : null;
  return {
    context: req.requestContext,
    route: req.originalPath || req.path || '/',
    authenticated: Boolean(req.session?.user_id),
    publicBaseUrl: config.appBaseUrl,
    publicScheme: config.publicScheme,
    supportEmail: config.supportEmail,
    turnstile: {
      enabled: Boolean(config.turnstile.enabled),
      siteKey: config.turnstile.enabled ? config.turnstile.siteKey : ''
    },
    policies: {
      terms: '/terms', privacy: config.privacyPolicyUrl, acceptableUse: '/acceptable-use', billing: '/billing',
      security: '/security', aiTransparency: '/ai-transparency', cookies: '/cookies',
      communicationCompliance: '/communication-compliance'
    },
    offer: {
      trialDays: config.billing.trialDays,
      foundingLimit: config.billing.foundingLimit,
      foundingAmountCents: config.billing.foundingAmountCents,
      standardAmountCents: config.billing.standardAmountCents,
      currency: config.billing.currency
    },
    workspace: tenant ? {
      name: tenant.name, path: '/app', url: workspaceUrl(config)
    } : null,
    feedback: { eligible: feedbackEligible, href: feedbackHref }
  };
}

function messageHistoryView(event) {
  return {
    id: event.id,
    customerId: event.customer_id,
    type: event.event_type,
    providerName: event.provider_name,
    providerMessageId: event.provider_message_id,
    recipient: event.recipient,
    subject: event.subject,
    text: event.text_body || event.message,
    html: event.html_body,
    from: event.from_address,
    cc: event.cc || [],
    bcc: event.bcc || [],
    replyTo: event.reply_to || [],
    tags: event.tags || [],
    deliveryStatus: event.last_event || 'sent',
    internetMessageId: event.internet_message_id,
    emailerCreatedAt: event.emailer_created_at,
    scheduledAt: event.scheduled_at,
    sentAt: event.created_at,
    lastCheckedAt: event.last_synced_at,
    syncError: event.sync_error
  };
}

async function sendCustomerMessage({ datastore, messenger, tenant, customer, config, followUp = false, actor = {} }) {
  if (!customer?.email) throw new HttpError(400, content('errors.customerEmailRequired', {}, 'Add an email address before sending this nudge.'));
  const security = await datastore.getTenantSecurityState(tenant.id);
  const limits = sendLimitsForTenant(security, config);
  const recipientHash = hashAbuseIdentifier(customer.email, config.abuse.identifierSalt);
  const sourceIpHash = actor.sourceIp ? hashAbuseIdentifier(actor.sourceIp, config.abuse.identifierSalt) : null;
  const reservation = await datastore.reserveSend(tenant, {
    id: crypto.randomUUID(),
    userId: actor.userId || null,
    sessionId: actor.sessionId || null,
    recipientHash,
    recipientDomain: recipientDomain(customer.email),
    sourceIpHash,
    messageType: followUp ? 'follow_up' : 'initial',
    cooldownHours: config.abuse.recipientCooldownHours,
    outboundEmailEnabled: config.abuse.outboundEmailEnabled,
    controlsEnabled: config.abuse.enabled,
    limits
  });
  if (!reservation.allowed) {
    await datastore.recordAbuseAudit?.({
      tenantId: tenant.id, userId: actor.userId || null, action: followUp ? 'follow-up-send' : 'initial-send',
      outcome: 'blocked', reason: reservation.reason, sourceIpHash, recipientHash,
      metadata: { customerId: customer.id, limits, counts: reservation.counts || {} }
    });
    if (config.abuse.enabled && typeof datastore.countRecentBlockedAttempts === 'function' && typeof datastore.restrictTenant === 'function') {
      const blockedAttempts = await datastore.countRecentBlockedAttempts(tenant.id, 60);
      if (blockedAttempts >= config.abuse.blockedAttemptRestrictionThreshold) {
        await datastore.restrictTenant(tenant.id, 'Sending restricted after repeated blocked send attempts.', { blockedAttempts, windowMinutes: 60 });
      }
    }
    throw new HttpError(429, reservation.reason);
  }
  const settings = await datastore.getSettings(tenant);
  const message = followUp
    ? content('emails.campaign.followUpLead', { message: renderTemplate(settings.template, customer, settings) }, `Just a friendly reminder — ${renderTemplate(settings.template, customer, settings)}`)
    : renderTemplate(settings.template, customer, settings);
  try {
    const result = await messenger.sendReviewRequest({
      customer, message, tenant, settings,
      logoData: settings.email_logo_data || null,
      logoMime: settings.email_logo_mime || '',
      followUp
    });
    if (followUp) await datastore.markFollowUpSent(tenant, customer.id);
    else await datastore.markCustomerSent(tenant, customer.id, settings.follow_up_days);
    await datastore.appendMessageEvent(tenant, {
      id: crypto.randomUUID(), customerId: customer.id, eventType: followUp ? 'follow-up-sent' : 'sent',
      providerName: result.providerName, providerMessageId: result.providerMessageId, recipient: result.recipient, message,
      subject: result.subject, text: result.text, html: result.html, from: result.from,
      cc: result.cc, bcc: result.bcc, replyTo: result.replyTo, tags: result.tags,
      lastEvent: result.lastEvent, emailerPayload: result.emailerPayload
    });
    await datastore.finalizeSendReservation(reservation.reservation.id, {
      status: 'sent', providerName: result.providerName, providerMessageId: result.providerMessageId
    });
    await datastore.recordAbuseAudit?.({
      tenantId: tenant.id, userId: actor.userId || null, action: followUp ? 'follow-up-send' : 'initial-send',
      outcome: 'allowed', sourceIpHash, recipientHash,
      metadata: { customerId: customer.id, providerName: result.providerName, providerMessageId: result.providerMessageId }
    });
    return { result, message };
  } catch (error) {
    await datastore.finalizeSendReservation(reservation.reservation.id, { status: 'failed', failureReason: error.message });
    await datastore.recordAbuseAudit?.({
      tenantId: tenant.id, userId: actor.userId || null, action: followUp ? 'follow-up-send' : 'initial-send',
      outcome: 'failed', reason: error.message, sourceIpHash, recipientHash, metadata: { customerId: customer.id }
    });
    throw error;
  }
}

export function createApp({ config = getConfig(), datastore = defaultDatastore, messenger } = {}) {
  config = effectiveConfig(config);
  messenger ||= createMessenger(config);

  const listener = async (req, res) => {
    setSecurityHeaders(res);
    try {
      const requestUrl = new URL(req.url || '/', 'http://reviewnudge.internal');
      const originalPathname = requestUrl.pathname;
      await resolveRequestContext(req, datastore, config, originalPathname);
      const pathname = req.routePath || originalPathname;
      req.path = pathname; req.originalPath = originalPathname; req.query = requestUrl.searchParams;
      enforceSameOrigin(req);
      const body = await readRequestBody(req);
      req.rawBody = body.raw; req.body = body.json;
      await loadSession({ req, datastore });
      if (req.session) {
        req.tenantContext = tenantFromSession(req.session);
        req.requestContext = 'tenant';
      }

      if (isStaticPath(pathname) && req.method === 'GET') { await serveStatic(pathname, res, config); return; }
      if (req.method === 'GET' && (pathname === '/livez' || pathname === '/healthz')) { sendJson(res, 200, { ok: true }); return; }
      if (req.method === 'GET' && pathname === '/readyz') { sendJson(res, 200, { ok: true, database: await datastore.health() }); return; }
      if (req.method === 'GET' && pathname === '/api/context') { sendJson(res, 200, publicContextResponse(req, config)); return; }

      if (req.method === 'POST' && pathname === '/api/waitlist') {
        requirePublicHost(req);
        const email = cleanEmail(req.body?.email);
        if (!email) throw new HttpError(400, 'Enter a valid email address.');
        const source = cleanText(req.body?.source || 'coming-soon', 80) || 'coming-soon';
        const signup = await datastore.createWaitlistSignup({
          email,
          source,
          ipHash: hashAbuseIdentifier(clientIp(req), config.abuse.identifierSalt),
          userAgent: cleanText(req.headers['user-agent'], 300),
          metadata: {
            path: req.originalPath || pathname,
            referrer: cleanText(req.headers.referer, 300)
          }
        });
        sendJson(res, signup.created ? 201 : 200, {
          ok: true,
          duplicate: !signup.created,
          message: signup.created
            ? 'You’re on the ReviewNudge waitlist.'
            : 'You’re already on the ReviewNudge waitlist.'
        });
        return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/signup') {
        requirePublicHost(req);
        const email = cleanEmail(req.body?.email); const password = String(req.body?.password || ''); const confirmPassword = String(req.body?.confirmPassword || '');
        const displayName = cleanText(req.body?.displayName, 80); const businessName = cleanText(req.body?.businessName, 120);
        const reviewDestination = validateReviewDestination(req.body?.reviewUrl, config.abuse.blockedShortenerDomains);
        const reviewUrl = reviewDestination.ok ? reviewDestination.url : '';
        const signupEmailDomain = recipientDomain(email);
        if (!email || !password || !displayName || !businessName || !reviewUrl) throw new HttpError(400, content('errors.signupRequired', {}, 'Add the business name, review URL, first name, email, and password.'));
        if (config.abuse.blockedSignupEmailDomains.includes(signupEmailDomain)) throw new HttpError(400, content('errors.blockedOwnerEmail', {}, 'Please use a business or personal email address allowed for workspace ownership.'));
        if (!reviewDestination.ok) throw new HttpError(400, reviewDestination.reason);
        if (!['on', 'true', true].includes(req.body?.policyConsent)) throw new HttpError(400, content('errors.policyRequired', {}, 'Please accept the policies before creating the workspace.'));
        if (password.length < 10) throw new HttpError(400, content('errors.passwordLength', {}, 'Use a password with at least 10 characters.'));
        if (password !== confirmPassword) throw new HttpError(400, content('errors.passwordMatch', {}, 'Those passwords do not match.'));
        const ip = clientIp(req);
        await enforceRateLimit(datastore, config, { scope: 'signup-ip', identifier: ip, windowSeconds: 3600, limit: config.abuse.signupIpHourlyLimit });
        await enforceRateLimit(datastore, config, { scope: 'signup-email', identifier: email, windowSeconds: 86400, limit: config.abuse.signupEmailDailyLimit });
        const turnstile = await verifyTurnstile({ token: req.body?.turnstileToken || req.body?.['cf-turnstile-response'], remoteIp: ip, config });
        if (!turnstile.success) throw new HttpError(403, content('errors.human', {}, 'The human check did not work. Please try once more.'));
        const slugBase = normalizeTenantSlug(businessName) || 'workspace';
        const suffix = crypto.randomBytes(3).toString('hex');
        const slug = `${slugBase.slice(0, Math.max(1, 41 - suffix.length))}-${suffix}`;
        const bootstrapToken = crypto.randomBytes(32).toString('base64url');
        const bootstrapExpiresAt = new Date(Date.now() + config.bootstrapTtlMinutes * 60_000).toISOString();
        const verificationToken = crypto.randomBytes(32).toString('base64url');
        const verificationExpiresAt = new Date(Date.now() + config.abuse.emailVerificationTtlHours * 3600_000).toISOString();
        try {
          const result = await datastore.signupAccount({
            userId: crypto.randomUUID(), tenantId: crypto.randomUUID(), email,
            passwordHash: await hashPassword(password), displayName, businessName, reviewUrl, slug,
            followUpDays: config.defaults.followUpDays, template: defaultTemplate,
            bootstrapTokenHash: tokenHash(bootstrapToken), bootstrapExpiresAt,
            verificationTokenHash: tokenHash(verificationToken), verificationExpiresAt,
            policyVersion: config.policyVersion,
            sourceIpHash: hashAbuseIdentifier(ip, config.abuse.identifierSalt)
          });
          let verificationEmailSent = true;
          try {
            await sendVerificationEmail({ messenger, config, account: { email: result.user.email, slug: result.tenant.slug }, token: verificationToken });
          } catch (error) {
            verificationEmailSent = false;
            logger.error('Verification email failed', { tenantId: result.tenant.id, userId: result.user.id, error });
          }
          await datastore.recordAbuseAudit?.({
            tenantId: result.tenant.id, userId: result.user.id, action: 'workspace-signup', outcome: 'allowed',
            sourceIpHash: hashAbuseIdentifier(ip, config.abuse.identifierSalt),
            metadata: { turnstile: turnstile.skipped ? 'skipped' : 'verified', verificationEmailSent }
          });
          sendJson(res, 201, {
            workspace: { name: result.tenant.name, bootstrapUrl: workspaceTokenUrl(config, result.tenant.slug, 'setup_token', bootstrapToken) },
            account: { email: result.user.email, displayName: result.user.display_name, emailVerified: false },
            verificationRequired: true, verificationEmailSent,
            versionPolicy: 'one-workspace-per-email'
          });
        } catch (error) {
          if (error.code !== '23505') throw error;
          const emailConflict = String(error.constraint || '').includes('users_email') || String(error.detail || '').includes('(email)');
          throw new HttpError(409, emailConflict ? content('errors.emailConflict', {}, 'That email already owns a ReviewNudge workspace. Version 1 keeps one workspace per email.') : content('errors.workspaceConflict', {}, 'That workspace name is already in use. Try setup again.'));
        }
        return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/verify-email') {
        const token = String(req.body?.token || '');
        if (!token) throw new HttpError(400, content('errors.verifyTokenRequired', {}, 'That verification link is missing its token.'));
        const account = await datastore.consumeEmailVerificationToken(tokenHash(token));
        if (!account) throw new HttpError(401, content('errors.verifyInvalid', {}, 'That verification link has expired or is no longer valid.'));
        await datastore.recordAbuseAudit?.({ tenantId: account.tenant_id, userId: account.user_id, action: 'email-verification', outcome: 'allowed' });
        sendJson(res, 200, { ok: true, message: content('errors.verificationSuccess', {}, 'Email verified. You can start sending within your plan limits.') });
        return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/resend-verification') {
        requireAuth(req);
        if (req.session.email_verified_at) { sendJson(res, 200, { ok: true, message: content('errors.verificationAlready', {}, 'That email is already verified.') }); return; }
        await enforceRateLimit(datastore, config, {
          scope: 'verification-resend', identifier: `${req.session.user_id}:${clientIp(req)}`,
          windowSeconds: 3600, limit: config.abuse.verificationResendHourlyLimit
        });
        const token = crypto.randomBytes(32).toString('base64url');
        const expiresAt = new Date(Date.now() + config.abuse.emailVerificationTtlHours * 3600_000).toISOString();
        await datastore.createEmailVerificationToken({ tokenHash: tokenHash(token), userId: req.session.user_id, tenantId: req.session.tenant_id, expiresAt });
        await sendVerificationEmail({ messenger, config, account: { email: req.session.email, slug: req.tenantContext.slug }, token });
        sendJson(res, 200, { ok: true, message: content('errors.verificationSent', {}, 'Verification email sent.') });
        return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/bootstrap') {
        const token = String(req.body?.token || '');
        if (!token) throw new HttpError(400, content('errors.setupTokenRequired', {}, 'That setup link is missing its token.'));
        const account = await datastore.consumeBootstrapToken(tokenHash(token));
        if (!account) throw new HttpError(401, content('errors.setupInvalid', {}, 'That setup link has expired or is no longer valid.'));
        await createSession({ res, datastore, config, userId: account.user_id, tenantId: account.tenant_id });
        appendAccountHint(res, account, config); sendJson(res, 200, { ok: true }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/login') {
        const email = cleanEmail(req.body?.email); const password = String(req.body?.password || '');
        if (!email || !password) throw new HttpError(400, content('errors.loginRequired', {}, 'Enter your email and password.'));
        await enforceRateLimit(datastore, config, { scope: 'login-ip', identifier: clientIp(req), windowSeconds: 3600, limit: config.abuse.loginIpHourlyLimit });
        await enforceRateLimit(datastore, config, { scope: 'login-email', identifier: email, windowSeconds: 3600, limit: config.abuse.loginEmailHourlyLimit });
        const account = await datastore.findUserByEmail(email);
        if (!account || !(await verifyPassword(password, account.password_hash))) throw new HttpError(401, content('errors.loginInvalid', {}, 'Invalid email or password.'));
        await createSession({ res, datastore, config, userId: account.id || account.user_id, tenantId: account.tenant_id });
        appendAccountHint(res, account, config);
        sendJson(res, 200, {
          ok: true,
          redirectUrl: '/app',
          workspace: { name: account.tenant_name }
        });
        return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/forgot-password') {
        const email = cleanEmail(req.body?.email);
        if (email) {
          await enforceRateLimit(datastore, config, { scope: 'password-reset-ip', identifier: clientIp(req), windowSeconds: 3600, limit: config.abuse.passwordResetHourlyLimit });
          await enforceRateLimit(datastore, config, { scope: 'password-reset-email', identifier: email, windowSeconds: 3600, limit: config.abuse.passwordResetHourlyLimit });
          const account = await datastore.findUserByEmail(email);
          if (account) {
            const token = crypto.randomBytes(32).toString('base64url');
            const expiresAt = new Date(Date.now() + 30 * 60_000).toISOString();
            await datastore.createPasswordResetToken({ tokenHash: tokenHash(token), userId: account.user_id || account.id, tenantId: account.tenant_id, expiresAt });
            const resetUrl = workspaceTokenUrl(config, account.slug, 'reset_token', token);
            const message = content('emails.reset.message', {}, 'Use this secure link to choose a new ReviewNudge password. It expires in 30 minutes and works once.');
            await messenger.sendEmail({
              to: account.email,
              subject: content('emails.reset.subject', {}, 'Reset your ReviewNudge password'),
              text: `${message}

${content('emails.reset.fallbackLabel', {}, 'Reset password:')} ${resetUrl}`,
              html: transactionalHtmlMessage({
                title: content('emails.reset.title', {}, 'Choose a new password'),
                message,
                actionUrl: resetUrl,
                actionLabel: content('emails.reset.action', {}, 'Reset password'),
                privacyUrl: config.privacyPolicyUrl,
                supportEmail: config.supportEmail,
                footerNote: content('emails.reset.footer', {}, 'If you did not ask for this, you can safely ignore the message.')
              }),
              tags: [{ name: 'product', value: 'reviewnudge' }, { name: 'message_type', value: 'password_reset' }]
            });
          }
        }
        sendJson(res, 200, { ok: true, message: content('notifications.resetRequested', {}, 'If that account exists, a reset link is on its way.') }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/reset-password/validate') {
        const token = String(req.body?.token || '');
        const valid = Boolean(token) && await datastore.isPasswordResetTokenValid(tokenHash(token));
        sendJson(res, 200, { ok: true, valid }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/reset-password') {
        const token = String(req.body?.token || '');
        const password = String(req.body?.password || '');
        const confirmPassword = String(req.body?.confirmPassword || '');
        if (!token || password.length < 10 || password !== confirmPassword) throw new HttpError(400, content('errors.resetInvalidInput', {}, 'Use a valid reset link and enter the same password twice. Passwords need at least 10 characters.'));
        const reset = await datastore.consumePasswordResetToken(tokenHash(token));
        if (!reset) throw new HttpError(400, content('errors.resetInvalid', {}, 'That password-reset link has expired or is no longer valid.'));
        await datastore.updateUserPassword(reset.user_id, await hashPassword(password));
        sendJson(res, 200, { ok: true }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/passkey/register/options') {
        requireAuth(req);
        const existing = await datastore.listPasskeys(req.session.user_id, req.tenantContext.id);
        const options = await generateRegistrationOptions({
          rpName: 'ReviewNudge', rpID: config.appHost,
          userName: req.session.email, userDisplayName: req.session.display_name || req.session.email,
          attestationType: 'none', authenticatorSelection: { residentKey: 'preferred', userVerification: 'required' },
          excludeCredentials: existing.map(item => ({ id: item.credential_id, transports: item.transports || [] }))
        });
        await datastore.createWebauthnChallenge({ userId:req.session.user_id, tenantId:req.tenantContext.id, purpose:'registration', challenge:options.challenge, expiresAt:new Date(Date.now()+5*60_000).toISOString() });
        sendJson(res, 200, options); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/passkey/register/verify') {
        requireAuth(req);
        const challenge = await datastore.consumeWebauthnChallenge({ userId:req.session.user_id, tenantId:req.tenantContext.id, purpose:'registration' });
        if (!challenge) throw new HttpError(400, content('errors.passkeyRegistrationExpired', {}, 'That passkey setup session expired. Please start again.'));
        const verification = await verifyRegistrationResponse({ response:req.body, expectedChallenge:challenge.challenge, expectedOrigin:config.appBaseUrl, expectedRPID:config.appHost, requireUserVerification:true });
        if (!verification.verified || !verification.registrationInfo) throw new HttpError(400, content('errors.passkeyRegistrationFailed', {}, 'We could not verify that passkey. Please try again.'));
        const info = verification.registrationInfo;
        await datastore.savePasskey({ credentialId:info.credential.id, userId:req.session.user_id, tenantId:req.tenantContext.id, publicKey:info.credential.publicKey, counter:info.credential.counter, transports:req.body?.response?.transports || [], deviceType:info.credentialDeviceType, backedUp:info.credentialBackedUp });
        sendJson(res, 200, { ok:true }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/passkey/login/options') {
        const email = cleanEmail(req.body?.email);
        if (email) {
          await enforceRateLimit(datastore, config, { scope: 'passkey-login-ip', identifier: clientIp(req), windowSeconds: 3600, limit: config.abuse.loginIpHourlyLimit });
          await enforceRateLimit(datastore, config, { scope: 'passkey-login-email', identifier: email, windowSeconds: 3600, limit: config.abuse.loginEmailHourlyLimit });
        }
        const account = email ? await datastore.findUserByEmail(email) : null;
        if (!account) throw new HttpError(400, content('errors.passkeyEmailRequired', {}, 'Enter the account email before using a passkey.'));
        const credentials = await datastore.listPasskeys(account.user_id, account.tenant_id);
        if (!credentials.length) throw new HttpError(400, content('errors.passkeyMissing', {}, 'No passkey is set up for this account.'));
        const options = await generateAuthenticationOptions({ rpID:config.appHost, userVerification:'required', allowCredentials:credentials.map(item => ({ id:item.credential_id, transports:item.transports || [] })) });
        await datastore.createWebauthnChallenge({ userId:account.user_id, tenantId:account.tenant_id, purpose:'authentication', challenge:options.challenge, expiresAt:new Date(Date.now()+5*60_000).toISOString() });
        sendJson(res, 200, { ...options, userId:account.user_id }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/passkey/login/verify') {
        const userId = cleanText(req.body?.userId, 64);
        const credential = await datastore.getPasskey(req.body?.credential?.id);
        if (!credential || credential.user_id !== userId) throw new HttpError(401, content('errors.passkeyAuthFailed', {}, 'Passkey sign-in did not work. Please try again.'));
        const challenge = await datastore.consumeWebauthnChallenge({ userId, tenantId:credential.tenant_id, purpose:'authentication' });
        if (!challenge) throw new HttpError(400, content('errors.passkeyAuthExpired', {}, 'That passkey sign-in session expired. Please start again.'));
        const verification = await verifyAuthenticationResponse({ response:req.body.credential, expectedChallenge:challenge.challenge, expectedOrigin:config.appBaseUrl, expectedRPID:config.appHost, credential:{ id:credential.credential_id, publicKey:new Uint8Array(credential.public_key), counter:Number(credential.counter), transports:credential.transports || [] }, requireUserVerification:true });
        if (!verification.verified) throw new HttpError(401, content('errors.passkeyAuthFailed', {}, 'Passkey sign-in did not work. Please try again.'));
        await datastore.updatePasskeyCounter(credential.credential_id, verification.authenticationInfo.newCounter);
        await createSession({ res, datastore, config, userId:credential.user_id, tenantId:credential.tenant_id });
        appendAccountHint(res, { email:credential.email, display_name:credential.display_name, slug:credential.slug }, config);
        sendJson(res, 200, { ok:true }); return;
      }

      if (req.method === 'POST' && pathname === '/api/auth/logout') {
        requireAuth(req); await destroySession({ req, res, datastore, config }); sendJson(res, 200, { ok: true }); return;
      }

      if (req.method === 'GET' && pathname === '/api/me') {
        if (!req.session?.user_id) { sendJson(res, 200, { authenticated: false, context: req.requestContext }); return; }
        const tenant = currentTenant(req);
        const security = await datastore.getTenantSecurityState(tenant.id);
        const limits = sendLimitsForTenant(security, config);
        sendJson(res, 200, {
          authenticated: true,
          user: { id: req.session.user_id, email: req.session.email, displayName: req.session.display_name },
          tenant,
          billing: billingAccess(tenant, config),
          security: {
            emailVerified: Boolean(security?.email_verified_at),
            trustState: limits.state,
            sendingEnabled: Boolean(config.abuse.outboundEmailEnabled && security?.email_verified_at && !['restricted','suspended','pending'].includes(limits.state)),
            holdReason: security?.sending_hold_reason || null,
            limits
          },
          feedback: {
            eligible: Boolean(tenant.pricing_tier === 'founding' && config.foundingFeedbackEmail),
            href: tenant.pricing_tier === 'founding' && config.foundingFeedbackEmail
              ? `mailto:${config.foundingFeedbackEmail}?subject=${encodeURIComponent('ReviewNudge Founding 25 feedback')}`
              : null
          }
        });
        return;
      }

      const brandingLogo = pathname.match(/^\/api\/branding\/([^/]+)\/logo$/);
      if (brandingLogo && req.method === 'GET') {
        const logo = await datastore.getBrandLogoBySlug(decodeURIComponent(brandingLogo[1]));
        if (!logo) throw new HttpError(404, content('errors.logoNotFound', {}, 'We could not find that logo.'));
        res.statusCode = 200;
        res.setHeader('Content-Type', logo.mime);
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.setHeader('Content-Length', logo.data.length);
        res.end(logo.data);
        return;
      }

      if (req.method === 'GET' && pathname === '/api/settings') { requireAuth(req); const tenant = currentTenant(req); sendJson(res, 200, publicSettings(await datastore.getSettings(tenant), tenant, config)); return; }
      if (req.method === 'PUT' && pathname === '/api/settings') {
        requireRole(req, 'owner', 'admin'); requireWritable(req, config);
        await enforceAuthenticatedAction(req, datastore, config, 'settings-mutation', config.abuse.authenticatedMutationHourlyLimit);
        const businessName = req.body?.businessName === undefined ? undefined : cleanText(req.body.businessName, 120);
        const reviewDestination = req.body?.reviewUrl === undefined ? null : validateReviewDestination(req.body.reviewUrl, config.abuse.blockedShortenerDomains);
        const reviewUrl = reviewDestination === null ? undefined : (reviewDestination.ok ? reviewDestination.url : '');
        const followUpDays = req.body?.followUpDays === undefined ? undefined : Number(req.body.followUpDays);
        const template = req.body?.template === undefined ? undefined : cleanText(req.body.template, 2000);
        const emailThemeCode = req.body?.emailThemeCode === undefined ? undefined : cleanText(req.body.emailThemeCode, 20).toLowerCase();
        const logo = parseEmailLogoDataUrl(req.body?.emailLogoDataUrl);
        if (reviewDestination && !reviewDestination.ok) throw new HttpError(400, reviewDestination.reason);
        if (followUpDays !== undefined && (!Number.isInteger(followUpDays) || followUpDays < 1 || followUpDays > 30)) throw new HttpError(400, content('errors.followUpRange', {}, 'Choose a follow-up between 1 and 30 days.'));
        if (emailThemeCode !== undefined && !emailThemeCodes.has(emailThemeCode)) throw new HttpError(400, content('errors.emailStyle', {}, 'Choose one of the available email styles.'));
        const tenant = currentTenant(req);
        const updated = await datastore.updateSettings(tenant, {
          businessName, reviewUrl, followUpDays, template, emailThemeCode,
          logoChanged: logo.changed, emailLogoData: logo.data, emailLogoMime: logo.mime
        });
        sendJson(res, 200, publicSettings(updated, tenant, config)); return;
      }


      if (req.method === 'GET' && pathname === '/api/slack/status') {
        requireAuth(req);
        const connection = await datastore.getSlackConnection?.(req.session.tenant_id);
        sendJson(res, 200, { slack: slackConnectionView(connection), configured: Boolean(config.slack.enabled && config.slack.clientId) });
        return;
      }

      if (req.method === 'GET' && pathname === '/api/slack/install') {
        requireRole(req, 'owner');
        if (!config.slack.enabled || !config.slack.clientId || !config.slack.clientSecret || !config.slack.tokenEncryptionKey) throw new HttpError(503, 'Slack is not configured for this environment.');
        const state = crypto.randomBytes(32).toString('base64url');
        const expiresAt = new Date(Date.now() + config.slack.oauthStateTtlMinutes * 60_000).toISOString();
        await datastore.createSlackOAuthState({ stateHash: tokenHash(state), tenantId: req.session.tenant_id, userId: req.session.user_id, expiresAt });
        redirect(res, slackInstallUrl(config, state), 302);
        return;
      }

      if (req.method === 'GET' && pathname === '/api/slack/oauth/callback') {
        const code = cleanText(req.query.get('code'), 2000);
        const state = cleanText(req.query.get('state'), 2000);
        const oauthError = cleanText(req.query.get('error'), 200);
        if (oauthError) { redirect(res, `/app?slack=error&reason=${encodeURIComponent(oauthError)}`, 302); return; }
        if (!code || !state) throw new HttpError(400, 'Slack OAuth code and state are required.');
        const stateRow = await datastore.consumeSlackOAuthState(tokenHash(state));
        if (!stateRow) throw new HttpError(401, 'Slack OAuth state expired or was already used.');
        const tenant = await datastore.findTenantById(stateRow.tenant_id);
        if (!tenant) throw new HttpError(404, 'Workspace not found for Slack install.');
        const payload = await exchangeSlackOAuthCode({ config, code });
        const webhook = payload.incoming_webhook || {};
        await datastore.upsertSlackConnection(tenant.id, {
          teamId: payload.team?.id || '',
          teamName: payload.team?.name || '',
          botUserId: payload.bot_user_id || '',
          appId: payload.app_id || '',
          scope: payload.scope || '',
          channelId: webhook.channel_id || '',
          channelName: webhook.channel || '',
          incomingWebhookUrlEncrypted: webhook.url ? encryptSlackSecret(webhook.url, config.slack.tokenEncryptionKey) : null,
          botAccessTokenEncrypted: payload.access_token ? encryptSlackSecret(payload.access_token, config.slack.tokenEncryptionKey) : null,
          connectedBy: stateRow.user_id
        });
        redirect(res, '/app?slack=connected', 302);
        return;
      }

      if (req.method === 'POST' && pathname === '/api/slack/disconnect') {
        requireRole(req, 'owner');
        await datastore.disconnectSlackConnection?.(req.session.tenant_id);
        sendJson(res, 200, { ok: true, slack: { connected: false, enabled: false } });
        return;
      }

      if (req.method === 'POST' && pathname === '/api/slack/test') {
        requireRole(req, 'owner');
        const tenant = currentTenant(req);
        const connection = await datastore.getSlackConnection?.(tenant.id);
        if (!connection?.enabled || !connection.incoming_webhook_url_encrypted) throw new HttpError(400, 'Connect Slack before sending a test message.');
        const webhookUrl = decryptSlackSecret(connection.incoming_webhook_url_encrypted, config.slack.tokenEncryptionKey);
        await postSlackWebhook({
          webhookUrl,
          text: `ReviewNudge Slack test for ${tenant.name}.`,
          blocks: [
            { type: 'header', text: { type: 'plain_text', text: 'ReviewNudge Slack test', emoji: true } },
            { type: 'section', text: { type: 'mrkdwn', text: `Slack is connected for *${tenant.name}*.` } }
          ],
          timeoutMs: config.slack.timeoutMs
        });
        sendJson(res, 200, { ok: true });
        return;
      }

      if (req.method === 'GET' && pathname === '/api/customers') { requireAuth(req); sendJson(res, 200, await datastore.listCustomers(currentTenant(req))); return; }
      if (req.method === 'POST' && pathname === '/api/customers') {
        requireWritable(req, config);
        await enforceAuthenticatedAction(req, datastore, config, 'customer-mutation', config.abuse.authenticatedMutationHourlyLimit);
        const tenant = currentTenant(req);
        const security = await datastore.getTenantSecurityState(tenant.id);
        const customerLimit = customerLimitForTenant(security, config);
        const customerCount = await datastore.countCustomers(tenant);
        if (customerCount >= customerLimit) throw new HttpError(429, content('errors.customerLimit', { limit: customerLimit }, `This workspace has reached its current customer limit (${customerLimit}).`));
        const name = cleanText(req.body?.name, 120); if (!name) throw new HttpError(400, content('errors.nameRequired', {}, 'Add the customer’s name.'));
        const email = req.body?.email ? cleanEmail(req.body.email) : '';
        if (req.body?.email && !email) throw new HttpError(400, content('errors.customerEmailInvalid', {}, 'That customer email address does not look right.'));
        const customer = await customerWrite(() => datastore.createCustomer(tenant, {
          id: crypto.randomUUID(), name, phone: cleanText(req.body?.phone, 40) || null,
          email: email || null, job: cleanText(req.body?.job, 160) || null,
          updatedBy: req.session.user_id
        }));
        sendJson(res, 201, customer); return;
      }

      if (req.method === 'POST' && pathname === '/api/customers/send-initial') {
        requireWritable(req, config);
        await enforceAuthenticatedAction(req, datastore, config, 'send-action', config.abuse.sendActionHourlyLimit);
        const tenant = currentTenant(req);
        const candidates = await datastore.listInitialSendCandidates(tenant, config.jobs.batchSize);
        const results = [];
        for (const customer of candidates) {
          try { await sendCustomerMessage({ datastore, messenger, tenant, customer, config, actor: { userId: req.session.user_id, sessionId: req.session.session_id, sourceIp: clientIp(req) } }); results.push({ id: customer.id, ok: true }); }
          catch (error) { results.push({ id: customer.id, ok: false, error: error.message }); }
        }
        sendJson(res, 200, { eligible: candidates.length, sent: results.filter(item => item.ok).length, failed: results.filter(item => !item.ok).length, results }); return;
      }

      const customerDetail = pathname.match(/^\/api\/customers\/([^/]+)$/);
      if (customerDetail && req.method === 'PUT') {
        requireWritable(req, config);
        await enforceAuthenticatedAction(req, datastore, config, 'customer-mutation', config.abuse.authenticatedMutationHourlyLimit);
        const customerId = decodeURIComponent(customerDetail[1]);
        const name = cleanText(req.body?.name, 120);
        if (!name) throw new HttpError(400, content('errors.nameRequired', {}, 'Add the customer’s name.'));
        const email = req.body?.email ? cleanEmail(req.body.email) : '';
        if (req.body?.email && !email) throw new HttpError(400, content('errors.customerEmailInvalid', {}, 'That customer email address does not look right.'));
        const customer = await customerWrite(() => datastore.updateCustomer(currentTenant(req), customerId, {
          name,
          phone: cleanText(req.body?.phone, 40) || null,
          email: email || null,
          job: cleanText(req.body?.job, 160) || null,
          updatedBy: req.session.user_id
        }));
        if (!customer) throw new HttpError(404, content('errors.customerNotFound', {}, 'We could not find that customer.'));
        sendJson(res, 200, customer); return;
      }

      const customerMessages = pathname.match(/^\/api\/customers\/([^/]+)\/messages$/);
      if (customerMessages && req.method === 'GET') {
        requireAuth(req);
        const customerId = decodeURIComponent(customerMessages[1]);
        const customer = await datastore.getCustomer(currentTenant(req), customerId, { includeArchived: true });
        if (!customer) throw new HttpError(404, content('errors.customerNotFound', {}, 'We could not find that customer.'));
        const events = await datastore.listMessageEvents(currentTenant(req), customerId);
        sendJson(res, 200, { customer, messages: events.map(messageHistoryView) }); return;
      }

      const customerAction = pathname.match(/^\/api\/customers\/([^/]+)\/(send|reviewed|archive)$/);
      if (req.method === 'POST' && customerAction) {
        requireWritable(req, config);
        const actionLimit = customerAction[2] === 'send' ? config.abuse.sendActionHourlyLimit : config.abuse.authenticatedMutationHourlyLimit;
        const actionScope = customerAction[2] === 'send' ? 'send-action' : 'customer-mutation';
        await enforceAuthenticatedAction(req, datastore, config, actionScope, actionLimit);
        const customerId = decodeURIComponent(customerAction[1]); const tenant = currentTenant(req);
        if (customerAction[2] === 'archive') {
          const customer = await datastore.archiveCustomer(tenant, customerId, req.session.user_id);
          if (!customer) throw new HttpError(404, content('errors.customerNotFound', {}, 'We could not find that customer.'));
          sendJson(res, 200, { ok: true, customer }); return;
        }
        if (customerAction[2] === 'reviewed') {
          const customer = await datastore.markCustomerReviewed(tenant, customerId);
          if (!customer) throw new HttpError(404, content('errors.customerNotFound', {}, 'We could not find that customer.'));
          sendJson(res, 200, customer); return;
        }
        const customer = await datastore.getCustomer(tenant, customerId);
        if (!customer) throw new HttpError(404, content('errors.customerNotFound', {}, 'We could not find that customer.'));
        const sent = await sendCustomerMessage({ datastore, messenger, tenant, customer, config, actor: { userId: req.session.user_id, sessionId: req.session.session_id, sourceIp: clientIp(req) } });
        sendJson(res, 200, {
          customer: await datastore.getCustomer(tenant, customer.id),
          sendResult: { providerMessageId: sent.result.providerMessageId, recipient: sent.result.recipient },
          message: sent.message
        }); return;
      }

      if (req.method === 'POST' && pathname === '/api/billing/checkout') {
        requireRole(req, 'owner');
        await enforceAuthenticatedAction(req, datastore, config, 'billing-checkout', config.abuse.billingCheckoutHourlyLimit);
        if (!config.billing.checkoutTokenKey) throw new HttpError(503, content('errors.checkoutUnavailable', {}, 'Checkout is not ready yet. Please try again later or contact support.'));
        const tenant = currentTenant(req);
        const expiresAt = new Date(Date.now() + config.billing.checkoutTokenTtlMinutes * 60_000).toISOString();
        const checkout = await datastore.createCheckoutRequest({
          tenant, user: { id: req.session.user_id }, config, emailHash: emailHash(req.session.email), expiresAt
        });
        const nowSeconds = Math.floor(Date.now() / 1000);
        const token = sealToken({
          v: 1, iss: config.billing.tokenIssuer, aud: config.billing.tokenAudience,
          sub: req.session.user_id, email: req.session.email, emailHash: emailHash(req.session.email),
          tenantId: tenant.id, workspaceSlug: tenant.slug, productCode: checkout.product_code,
          pricingTier: checkout.pricing_tier, amountCents: Number(checkout.amount_cents), currency: checkout.currency,
          jti: checkout.id, iat: nowSeconds, exp: Math.floor(new Date(checkout.expires_at).getTime() / 1000),
          returnUrl: workspaceUrl(config)
        }, config.billing.checkoutTokenKey);
        sendJson(res, 201, {
          checkoutUrl: `${config.billing.paymentAppUrl}/checkout?t=${encodeURIComponent(token)}`,
          pricingTier: checkout.pricing_tier, amountCents: Number(checkout.amount_cents), currency: checkout.currency,
          expiresAt: checkout.expires_at
        }); return;
      }

      if (req.method === 'POST' && pathname === '/api/internal/billing/checkout/claim') {
        requirePublicHost(req);
        if (!verifyInternalRequest(req.headers, req.rawBody, config.billing.internalSecret)) throw new HttpError(401, 'invalid internal signature');
        const claimed = await datastore.claimCheckoutRequest(req.body || {});
        if (!claimed) throw new HttpError(409, 'checkout request is invalid, expired, completed, or does not match the encrypted token');
        sendJson(res, 200, { ok: true, checkout: claimed }); return;
      }

      if (req.method === 'POST' && pathname === '/api/internal/billing/events') {
        requirePublicHost(req);
        if (!verifyInternalRequest(req.headers, req.rawBody, config.billing.internalSecret)) throw new HttpError(401, 'invalid internal signature');
        if (!req.body?.providerEventId || !req.body?.type) throw new HttpError(400, 'provider event id and type are required');
        sendJson(res, 200, await datastore.applyBillingEvent(req.body)); return;
      }

      if (req.method === 'POST' && pathname === '/api/internal/reviews/events') {
        requirePublicHost(req);
        if (!verifyInternalRequest(req.headers, req.rawBody, config.reviews.eventSecret)) throw new HttpError(401, 'invalid review-provider signature');
        const input = req.body || {};
        if (!input.tenantId || !input.provider || !input.providerEventId) throw new HttpError(400, 'tenant, provider, and provider event id are required');
        const recorded = await datastore.recordReviewProviderEvent({ ...input, payload: input });
        if (recorded.duplicate) { sendJson(res, 200, { duplicate: true }); return; }
        const tenant = await datastore.findTenantById(input.tenantId);
        if (!tenant) throw new HttpError(404, 'tenant not found');
        const customers = await datastore.listCustomers(tenant);
        const match = matchReviewToCustomers(input, customers);
        const customer = await datastore.applyReviewMatch(tenant, recorded.event.id, match);
        let slack = { skipped: true };
        try {
          slack = await notifySlackOfReview({ datastore, tenant, review: recorded.event, match, customer, config });
        } catch (error) {
          logger.error('Slack review notification failed', { tenantId: tenant.id, providerEventId: input.providerEventId, error });
          slack = { ok: false, error: error.message };
        }
        sendJson(res, 200, { duplicate: false, match, customer, slack }); return;
      }

      if (pathname.startsWith('/api/')) throw new HttpError(404, content('errors.notFound', {}, 'We could not find that.'));
      if (req.method === 'GET' && (pathname === '/pricing' || pathname === '/support')) {
        const section = pathname.slice(1);
        redirect(res, `${config.appBaseUrl}/#${section}`, 302);
        return;
      }
      if (req.method === 'GET' && pathname === '/privacy') {
        redirect(res, config.privacyPolicyUrl, 302);
        return;
      }
      if (req.method === 'GET' && pathname === '/app') {
        if (!req.session?.user_id && !requestUrl.searchParams.get('setup_token')) { redirect(res, '/login', 302); return; }
        await servePublicPage(res); return;
      }
      if (req.method === 'GET' && publicRoutes.has(pathname)) { await servePublicPage(res); return; }
      throw new HttpError(404, content('errors.notFound', {}, 'We could not find that.'));
    } catch (error) {
      const status = Number(error.status) || 500;
      if (status >= 500) logger.error('Request failed', { error, status, method: req.method, path: req.path || req.url });
      const isApi = String(req.path || '').startsWith('/api/') || ['/livez', '/readyz', '/healthz'].includes(req.path);
      if (isApi) sendJson(res, status, { error: status >= 500 ? content('errors.internal', {}, 'Something went wrong on our side. Please try again.') : error.message });
      else sendBrandedError(res, status, status >= 500 ? 'ReviewNudge could not complete this request.' : error.message, config);
    }
  };

  listener.listen = (...args) => http.createServer(listener).listen(...args);
  return listener;
}

export async function startServer({ config = getConfig(), datastore = defaultDatastore } = {}) {
  config = effectiveConfig(config);
  await datastore.initialize();
  const app = createApp({ config, datastore, messenger: createMessenger(config) });
  const server = app.listen(config.port, '0.0.0.0', () => {
    logger.info('ReviewNudge listening', { port: config.port, stack: config.stack });
    logger.info('Public host configured', { publicHost: config.appHost });
    logger.info('Application routes configured', { login: '/login', app: '/app', resetPassword: '/reset-password', verifyEmail: '/verify-email' });
    logger.info('Runtime adapter configured', { runtimeAdapterCode: config.runtimeAdapterCode });
    logger.info('Message transport configured', { messageTransport: config.messageTransport });
  });
  const shutdown = async signal => {
    logger.info('Shutdown signal received', { signal });
    server.close(async () => { await datastore.close(); process.exit(0); });
  };
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
  return server;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === __filename;
if (isMain) startServer().catch(error => { logger.error('ReviewNudge startup failure', { error }); process.exit(1); });
