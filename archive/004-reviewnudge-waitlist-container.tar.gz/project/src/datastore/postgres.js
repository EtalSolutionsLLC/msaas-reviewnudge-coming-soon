import crypto from 'crypto';
import { readFile, readdir } from 'fs/promises';
import pg from 'pg';
import { fileURLToPath } from 'url';

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function safeTenantSchema(slug) {
  const normalized = String(slug || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 48);
  if (!normalized || !/^[a-z][a-z0-9_]*$/.test(normalized)) throw new Error('tenant slug cannot be converted to a safe SQL schema');
  return `tenant_${normalized}`;
}

function quoteIdent(identifier) {
  if (!/^[a-z_][a-z0-9_]*$/.test(identifier)) throw new Error('unsafe SQL identifier');
  return `"${identifier}"`;
}

function sslConfig(mode) {
  if (mode === 'disable') return false;
  if (mode === 'require') return { rejectUnauthorized: true };
  if (mode === 'no-verify') return { rejectUnauthorized: false };
  return undefined;
}

export class PostgresDatastore {
  constructor(config) {
    this.config = config;
    this.pool = null;
  }

  ensurePool() {
    if (this.pool) return this.pool;
    if (!this.config.database.url) throw new Error('DATABASE_URL is required');
    this.pool = new pg.Pool({
      connectionString: this.config.database.url,
      max: this.config.database.poolMax,
      idleTimeoutMillis: this.config.database.idleTimeoutMs,
      connectionTimeoutMillis: this.config.database.connectionTimeoutMs,
      ssl: sslConfig(this.config.database.sslMode),
      application_name: `${this.config.stack}-web`
    });
    return this.pool;
  }

  async initialize() {
    this.ensurePool();
    let lastError;
    for (let attempt = 1; attempt <= this.config.database.startupAttempts; attempt += 1) {
      try {
        const migrationsDirectory = fileURLToPath(new URL('../../db/migrations/', import.meta.url));
        const migrations = (await readdir(migrationsDirectory)).filter(name => name.endsWith('.sql')).sort();
        for (const migrationName of migrations) {
          const migration = await readFile(`${migrationsDirectory}/${migrationName}`, 'utf8');
          await this.pool.query(migration);
        }
        await this.pool.query('DELETE FROM public.sessions WHERE expires_at <= now()');
        await this.pool.query('DELETE FROM public.bootstrap_tokens WHERE expires_at <= now() OR used_at IS NOT NULL');
        await this.pool.query('DELETE FROM public.email_verification_tokens WHERE expires_at <= now() OR used_at IS NOT NULL');
        await this.pool.query("DELETE FROM public.request_rate_limits WHERE updated_at < now() - interval '2 days'");
        await this.pool.query("UPDATE public.send_reservations SET status = 'released', finalized_at = now(), failure_reason = COALESCE(failure_reason, 'reservation expired') WHERE status = 'reserved' AND reserved_at < now() - interval '30 minutes'");
        return;
      } catch (error) {
        lastError = error;
        if (attempt === this.config.database.startupAttempts) break;
        await sleep(this.config.database.startupDelayMs);
      }
    }
    throw lastError;
  }

  async close() {
    if (this.pool) await this.pool.end();
    this.pool = null;
  }

  async health() {
    await this.pool.query('SELECT 1');
    return 'ok';
  }

  async createWaitlistSignup(input) {
    const result = await this.pool.query(`
      INSERT INTO public.waitlist_signups
        (email, source, ip_hash, user_agent, metadata)
      VALUES (lower($1), $2, $3, $4, COALESCE($5, '{}'::jsonb))
      ON CONFLICT (email) DO UPDATE
        SET source = COALESCE(NULLIF(EXCLUDED.source, ''), public.waitlist_signups.source),
            ip_hash = COALESCE(EXCLUDED.ip_hash, public.waitlist_signups.ip_hash),
            user_agent = COALESCE(EXCLUDED.user_agent, public.waitlist_signups.user_agent),
            metadata = public.waitlist_signups.metadata || COALESCE(EXCLUDED.metadata, '{}'::jsonb),
            updated_at = now()
      RETURNING *, (xmax = 0) AS created
    `, [
      input.email,
      input.source || 'coming-soon',
      input.ipHash || null,
      input.userAgent || null,
      input.metadata || {}
    ]);
    return result.rows[0];
  }



  async findTenantBySlug(slug) {
    const result = await this.pool.query(`
      SELECT *
      FROM public.tenants
      WHERE slug = lower($1)
      LIMIT 1
    `, [slug]);
    return result.rows[0] || null;
  }

  async findTenantById(id) {
    const result = await this.pool.query('SELECT * FROM public.tenants WHERE id = $1 LIMIT 1', [id]);
    return result.rows[0] || null;
  }

  async createTenantSchema(client, schemaName) {
    const schema = quoteIdent(schemaName);
    await client.query(`CREATE SCHEMA IF NOT EXISTS ${schema}`);
    await client.query(`
      CREATE TABLE IF NOT EXISTS ${schema}.settings (
        id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
        business_name text NOT NULL,
        review_url text NOT NULL,
        follow_up_days integer NOT NULL DEFAULT 3,
        template text NOT NULL,
        email_theme_code text NOT NULL DEFAULT 'light' CHECK (email_theme_code IN ('light','navy','warm','dark')),
        email_logo_data bytea,
        email_logo_mime text,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      )
    `);
    await client.query(`
      CREATE TABLE IF NOT EXISTS ${schema}.customers (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        name text NOT NULL,
        phone text,
        email text,
        job text,
        status text NOT NULL DEFAULT 'Ready' CHECK (status IN ('Ready','Sent','Opened','Review detected','Needs confirmation','Reviewed')),
        sent_at timestamptz,
        initial_sent_at timestamptz,
        follow_up_due_at timestamptz,
        follow_up_sent_at timestamptz,
        reviewed_at timestamptz,
        completion_source text,
        review_provider_event_id text,
        follow_up boolean NOT NULL DEFAULT false,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      )
    `);
    await client.query(`
      CREATE TABLE IF NOT EXISTS ${schema}.message_events (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        customer_id uuid REFERENCES ${schema}.customers(id) ON DELETE SET NULL,
        event_type text NOT NULL,
        provider_name text NOT NULL,
        provider_message_id text,
        recipient text,
        message text,
        subject text,
        html_body text,
        text_body text,
        from_address text,
        cc jsonb NOT NULL DEFAULT '[]'::jsonb,
        bcc jsonb NOT NULL DEFAULT '[]'::jsonb,
        reply_to jsonb NOT NULL DEFAULT '[]'::jsonb,
        tags jsonb NOT NULL DEFAULT '[]'::jsonb,
        internet_message_id text,
        last_event text,
        emailer_created_at timestamptz,
        scheduled_at timestamptz,
        emailer_payload jsonb,
        last_synced_at timestamptz,
        sync_attempted_at timestamptz,
        sync_error text,
        created_at timestamptz NOT NULL DEFAULT now()
      )
    `);
    await client.query(`
      CREATE TABLE IF NOT EXISTS ${schema}.message_event_snapshots (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        message_event_id uuid NOT NULL REFERENCES ${schema}.message_events(id) ON DELETE CASCADE,
        payload_hash text NOT NULL,
        last_event text,
        payload jsonb NOT NULL,
        captured_at timestamptz NOT NULL DEFAULT now(),
        UNIQUE (message_event_id, payload_hash)
      )
    `);
    await client.query(`ALTER TABLE ${schema}.settings ADD COLUMN IF NOT EXISTS email_theme_code text NOT NULL DEFAULT 'light'`);
    await client.query(`ALTER TABLE ${schema}.settings ADD COLUMN IF NOT EXISTS email_logo_data bytea`);
    await client.query(`ALTER TABLE ${schema}.settings ADD COLUMN IF NOT EXISTS email_logo_mime text`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS initial_sent_at timestamptz`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS follow_up_due_at timestamptz`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS follow_up_sent_at timestamptz`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS completion_source text`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS review_provider_event_id text`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS archived_at timestamptz`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS archived_by uuid`);
    await client.query(`ALTER TABLE ${schema}.customers ADD COLUMN IF NOT EXISTS updated_by uuid`);
    await client.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS uq_customers_active_email
      ON ${schema}.customers (lower(btrim(email)))
      WHERE archived_at IS NULL
        AND NULLIF(btrim(email), '') IS NOT NULL
    `);
    await client.query(`ALTER TABLE ${schema}.customers DROP CONSTRAINT IF EXISTS customers_status_check`);
    await client.query(`ALTER TABLE ${schema}.customers ADD CONSTRAINT customers_status_check CHECK (status IN ('Ready','Sent','Opened','Review detected','Needs confirmation','Reviewed'))`);
  }

  async signupAccount(input) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const user = (await client.query(`
        INSERT INTO public.users (id, email, password_hash, display_name, email_verified_at)
        VALUES ($1, lower($2), $3, $4, NULL)
        RETURNING id, email, display_name
      `, [input.userId, input.email, input.passwordHash, input.displayName || null])).rows[0];

      const schemaName = safeTenantSchema(input.slug);
      const tenant = (await client.query(`
        INSERT INTO public.tenants (id, name, slug, schema_name, onboarding_completed_at, trust_state)
        VALUES ($1, $2, $3, $4, now(), 'pending')
        RETURNING *
      `, [input.tenantId, input.businessName, input.slug, schemaName])).rows[0];

      await client.query(`
        INSERT INTO public.tenant_memberships (tenant_id, user_id, role)
        VALUES ($1, $2, 'owner')
      `, [tenant.id, user.id]);

      await this.createTenantSchema(client, schemaName);
      await client.query(`SET LOCAL search_path TO ${quoteIdent(schemaName)}, public`);
      await client.query(`
        INSERT INTO settings (business_name, review_url, follow_up_days, template)
        VALUES ($1, $2, $3, $4)
      `, [input.businessName, input.reviewUrl, input.followUpDays, input.template]);

      await client.query(`
        INSERT INTO public.bootstrap_tokens (token_hash, user_id, tenant_id, expires_at)
        VALUES ($1, $2, $3, $4)
      `, [input.bootstrapTokenHash, user.id, tenant.id, input.bootstrapExpiresAt]);

      await client.query(`
        INSERT INTO public.email_verification_tokens (token_hash, user_id, tenant_id, expires_at)
        VALUES ($1, $2, $3, $4)
      `, [input.verificationTokenHash, user.id, tenant.id, input.verificationExpiresAt]);

      for (const policyCode of ['terms', 'privacy', 'acceptable-use', 'communication-compliance']) {
        await client.query(`
          INSERT INTO public.policy_acceptances
            (user_id, tenant_id, policy_code, policy_version, source_ip_hash)
          VALUES ($1,$2,$3,$4,$5)
          ON CONFLICT DO NOTHING
        `, [user.id, tenant.id, policyCode, input.policyVersion, input.sourceIpHash || null]);
      }

      await client.query('COMMIT');
      return { user, tenant };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async findUserForTenantByEmail(email, tenantId) {
    const result = await this.pool.query(`
      SELECT u.id, u.email, u.display_name, u.password_hash,
             u.email_verified_at,
             t.id AS tenant_id, t.name AS tenant_name, t.slug, t.schema_name,
             t.onboarding_completed_at, t.created_at, t.trial_ends_at,
             t.subscription_status, t.pricing_tier, t.monthly_amount_cents, t.billing_currency,
             t.stripe_customer_id, t.stripe_subscription_id, t.founding_eligibility_lost_at,
             t.trust_state, t.sending_hold_reason, t.restricted_at, t.suspended_at, m.role
      FROM public.users u
      JOIN public.tenant_memberships m ON m.user_id = u.id
      JOIN public.tenants t ON t.id = m.tenant_id
      WHERE u.email = lower($1) AND t.id = $2
      LIMIT 1
    `, [email, tenantId]);
    return result.rows[0] || null;
  }

  async findUserByEmail(email) {
    const result = await this.pool.query(`
      SELECT u.id, u.id AS user_id, u.email, u.display_name, u.password_hash,
             u.email_verified_at,
             t.id AS tenant_id, t.name AS tenant_name, t.slug, t.schema_name,
             t.onboarding_completed_at, t.created_at, t.trial_ends_at,
             t.subscription_status, t.pricing_tier, t.monthly_amount_cents, t.billing_currency,
             t.stripe_customer_id, t.stripe_subscription_id, t.founding_eligibility_lost_at,
             t.trust_state, t.sending_hold_reason, t.restricted_at, t.suspended_at, m.role
      FROM public.users u
      JOIN public.tenant_memberships m ON m.user_id = u.id
      JOIN public.tenants t ON t.id = m.tenant_id
      WHERE u.email = lower($1)
      ORDER BY m.created_at ASC
      LIMIT 1
    `, [email]);
    return result.rows[0] || null;
  }

  async createSession({ id, userId, tenantId, expiresAt }) {
    await this.pool.query(`
      INSERT INTO public.sessions (id, user_id, tenant_id, expires_at)
      VALUES ($1, $2, $3, $4)
    `, [id, userId, tenantId, expiresAt]);
  }

  async deleteSession(id) {
    await this.pool.query('DELETE FROM public.sessions WHERE id = $1', [id]);
  }

  async getSession(id) {
    const result = await this.pool.query(`
      SELECT s.id AS session_id, s.expires_at,
             u.id AS user_id, u.email, u.display_name, u.email_verified_at,
             t.id AS tenant_id, t.name AS tenant_name, t.slug, t.schema_name,
             t.onboarding_completed_at, t.created_at, t.trial_ends_at,
             t.subscription_status, t.pricing_tier, t.monthly_amount_cents, t.billing_currency,
             t.stripe_customer_id, t.stripe_subscription_id, t.founding_eligibility_lost_at,
             t.trust_state, t.sending_hold_reason, t.restricted_at, t.suspended_at, m.role
      FROM public.sessions s
      JOIN public.users u ON u.id = s.user_id
      JOIN public.tenants t ON t.id = s.tenant_id
      JOIN public.tenant_memberships m ON m.user_id = u.id AND m.tenant_id = t.id
      WHERE s.id = $1 AND s.expires_at > now()
      LIMIT 1
    `, [id]);
    return result.rows[0] || null;
  }

  async touchSession(id) {
    await this.pool.query('UPDATE public.sessions SET last_seen_at = now() WHERE id = $1', [id]);
  }

  async consumeBootstrapToken(tokenHash, tenantId = null) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const token = (await client.query(`
        SELECT token_hash, user_id, tenant_id, expires_at, used_at
        FROM public.bootstrap_tokens
        WHERE token_hash = $1
          AND ($2::uuid IS NULL OR tenant_id = $2)
        FOR UPDATE
      `, [tokenHash, tenantId])).rows[0];
      if (!token || token.used_at || new Date(token.expires_at).getTime() <= Date.now()) {
        await client.query('ROLLBACK');
        return null;
      }
      await client.query('UPDATE public.bootstrap_tokens SET used_at = now() WHERE token_hash = $1', [tokenHash]);
      const result = await client.query(`
        SELECT u.id AS user_id, u.email, u.display_name, u.email_verified_at,
               t.id AS tenant_id, t.name AS tenant_name, t.slug, t.schema_name,
               t.onboarding_completed_at, t.created_at, t.trial_ends_at,
             t.subscription_status, t.pricing_tier, t.monthly_amount_cents, t.billing_currency,
             t.stripe_customer_id, t.stripe_subscription_id, t.founding_eligibility_lost_at,
             t.trust_state, t.sending_hold_reason, t.restricted_at, t.suspended_at, m.role
        FROM public.users u
        JOIN public.tenant_memberships m ON m.user_id = u.id
        JOIN public.tenants t ON t.id = m.tenant_id
        WHERE u.id = $1 AND t.id = $2
      `, [token.user_id, token.tenant_id]);
      await client.query('COMMIT');
      return result.rows[0] || null;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async createEmailVerificationToken({ tokenHash, userId, tenantId, expiresAt }) {
    await this.pool.query('DELETE FROM public.email_verification_tokens WHERE user_id = $1 AND tenant_id = $2', [userId, tenantId]);
    await this.pool.query(`
      INSERT INTO public.email_verification_tokens (token_hash, user_id, tenant_id, expires_at)
      VALUES ($1,$2,$3,$4)
    `, [tokenHash, userId, tenantId, expiresAt]);
  }

  async consumeEmailVerificationToken(tokenHash, tenantId = null) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const token = (await client.query(`
        SELECT * FROM public.email_verification_tokens
        WHERE token_hash = $1
          AND ($2::uuid IS NULL OR tenant_id = $2)
        FOR UPDATE
      `, [tokenHash, tenantId])).rows[0];
      if (!token || token.used_at || new Date(token.expires_at).getTime() <= Date.now()) {
        await client.query('ROLLBACK');
        return null;
      }
      await client.query('UPDATE public.email_verification_tokens SET used_at = now() WHERE token_hash = $1', [tokenHash]);
      await client.query('UPDATE public.users SET email_verified_at = COALESCE(email_verified_at, now()), updated_at = now() WHERE id = $1', [token.user_id]);
      await client.query(`
        UPDATE public.tenants
        SET trust_state = CASE WHEN trust_state = 'pending' THEN 'trial' ELSE trust_state END,
            sending_hold_reason = CASE WHEN trust_state = 'pending' THEN NULL ELSE sending_hold_reason END,
            updated_at = now()
        WHERE id = $1
      `, [tenantId]);
      const result = await client.query(`
        SELECT u.id AS user_id, u.email, u.display_name, u.email_verified_at,
               t.id AS tenant_id, t.name AS tenant_name, t.slug, t.trust_state
        FROM public.users u
        JOIN public.tenant_memberships m ON m.user_id = u.id
        JOIN public.tenants t ON t.id = m.tenant_id
        WHERE u.id = $1 AND t.id = $2
      `, [token.user_id, tenantId]);
      await client.query('COMMIT');
      return result.rows[0] || null;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async getTenantSecurityState(tenantId) {
    const result = await this.pool.query(`
      SELECT t.*, u.id AS owner_user_id, u.email AS owner_email, u.email_verified_at
      FROM public.tenants t
      JOIN public.tenant_memberships m ON m.tenant_id = t.id AND m.role = 'owner'
      JOIN public.users u ON u.id = m.user_id
      WHERE t.id = $1
      LIMIT 1
    `, [tenantId]);
    return result.rows[0] || null;
  }

  async consumeRateLimit({ scope, identifierHash, windowSeconds, limit }) {
    const result = await this.pool.query(`
      INSERT INTO public.request_rate_limits
        (scope, identifier_hash, window_seconds, window_started_at, request_count)
      VALUES ($1,$2,$3,now(),1)
      ON CONFLICT (scope, identifier_hash, window_seconds)
      DO UPDATE SET
        window_started_at = CASE
          WHEN public.request_rate_limits.window_started_at <= now() - make_interval(secs => EXCLUDED.window_seconds)
            THEN now()
          ELSE public.request_rate_limits.window_started_at
        END,
        request_count = CASE
          WHEN public.request_rate_limits.window_started_at <= now() - make_interval(secs => EXCLUDED.window_seconds)
            THEN 1
          ELSE public.request_rate_limits.request_count + 1
        END,
        updated_at = now()
      RETURNING request_count, window_started_at
    `, [scope, identifierHash, windowSeconds]);
    const row = result.rows[0];
    return {
      allowed: Number(row.request_count) <= Number(limit),
      count: Number(row.request_count),
      limit: Number(limit),
      resetAt: new Date(new Date(row.window_started_at).getTime() + windowSeconds * 1000).toISOString()
    };
  }

  async countCustomers(tenant) {
    const result = await this.withTenant(tenant, client => client.query('SELECT count(*)::integer AS count FROM customers WHERE archived_at IS NULL'));
    return Number(result.rows[0]?.count || 0);
  }

  async reserveSend(tenant, input) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const security = (await client.query(`
        SELECT t.*, u.email_verified_at
        FROM public.tenants t
        JOIN public.tenant_memberships m ON m.tenant_id = t.id AND m.role = 'owner'
        JOIN public.users u ON u.id = m.user_id
        WHERE t.id = $1
        FOR UPDATE OF t
      `, [tenant.id])).rows[0];
      if (!security) throw new Error('workspace not found');

      const counts = (await client.query(`
        SELECT
          count(*) FILTER (WHERE tenant_id = $1 AND reserved_at >= now() - interval '1 hour')::integer AS hourly,
          count(*) FILTER (WHERE tenant_id = $1 AND reserved_at >= now() - interval '1 day')::integer AS daily,
          count(*) FILTER (WHERE tenant_id = $1)::integer AS total,
          count(*) FILTER (WHERE user_id = $2 AND reserved_at >= now() - interval '1 hour')::integer AS user_hourly,
          count(*) FILTER (WHERE session_id = $3 AND reserved_at >= now() - interval '1 hour')::integer AS session_hourly,
          count(*) FILTER (WHERE source_ip_hash = $4 AND reserved_at >= now() - interval '1 hour')::integer AS ip_hourly,
          count(*) FILTER (WHERE tenant_id = $1 AND recipient_domain = $5 AND reserved_at >= now() - interval '1 day')::integer AS domain_daily,
          count(DISTINCT recipient_domain) FILTER (WHERE tenant_id = $1 AND reserved_at >= now() - interval '1 day')::integer AS unique_domains_daily,
          bool_or(tenant_id = $1 AND recipient_domain = $5 AND reserved_at >= now() - interval '1 day') AS domain_seen_today
        FROM public.send_reservations
        WHERE status IN ('reserved','sent','failed')
      `, [tenant.id, input.userId || null, input.sessionId || null, input.sourceIpHash || null, input.recipientDomain])).rows[0];

      const duplicate = (await client.query(`
        SELECT 1
        FROM public.send_reservations
        WHERE tenant_id = $1 AND recipient_hash = $2 AND status IN ('reserved','sent','failed')
          AND reserved_at >= now() - make_interval(hours => $3)
        LIMIT 1
      `, [tenant.id, input.recipientHash, input.cooldownHours])).rowCount > 0;

      const prospectiveUniqueDomains = Number(counts.unique_domains_daily || 0) + (counts.domain_seen_today ? 0 : 1);
      let reason = null;
      if (!input.outboundEmailEnabled) reason = 'Outbound email is temporarily disabled.';
      else if (!security.email_verified_at) reason = 'Verify the workspace owner email before sending.';
      else if (security.trust_state === 'restricted') reason = security.sending_hold_reason || 'Sending is temporarily restricted.';
      else if (security.trust_state === 'suspended') reason = security.sending_hold_reason || 'This workspace is suspended.';
      else if (Number(input.limits.hourly || 0) <= 0 || Number(input.limits.daily || 0) <= 0) reason = 'This workspace is not permitted to send yet.';
      else if (input.controlsEnabled !== false && Number(counts.hourly) >= Number(input.limits.hourly)) reason = `Hourly sending limit reached (${input.limits.hourly}).`;
      else if (input.controlsEnabled !== false && Number(counts.daily) >= Number(input.limits.daily)) reason = `Daily sending limit reached (${input.limits.daily}).`;
      else if (input.controlsEnabled !== false && input.limits.total !== null && Number(counts.total) >= Number(input.limits.total)) reason = `Trial sending limit reached (${input.limits.total}).`;
      else if (input.controlsEnabled !== false && input.userId && Number(counts.user_hourly) >= Number(input.limits.userHourly)) reason = `User hourly sending limit reached (${input.limits.userHourly}).`;
      else if (input.controlsEnabled !== false && input.sessionId && Number(counts.session_hourly) >= Number(input.limits.sessionHourly)) reason = `Session hourly sending limit reached (${input.limits.sessionHourly}).`;
      else if (input.controlsEnabled !== false && input.sourceIpHash && Number(counts.ip_hourly) >= Number(input.limits.ipHourly)) reason = `Source hourly sending limit reached (${input.limits.ipHourly}).`;
      else if (input.controlsEnabled !== false && Number(counts.domain_daily) >= Number(input.limits.recipientDomainDaily)) reason = `Daily sending limit reached for this recipient domain (${input.limits.recipientDomainDaily}).`;
      else if (input.controlsEnabled !== false && prospectiveUniqueDomains > Number(input.limits.uniqueRecipientDomainsDaily)) reason = `Daily recipient-domain diversity limit reached (${input.limits.uniqueRecipientDomainsDaily}).`;
      else if (input.controlsEnabled !== false && duplicate) reason = `This recipient was contacted within the last ${input.cooldownHours} hours.`;

      const normalizedCounts = {
        hourly: Number(counts.hourly || 0), daily: Number(counts.daily || 0), total: Number(counts.total || 0),
        userHourly: Number(counts.user_hourly || 0), sessionHourly: Number(counts.session_hourly || 0),
        ipHourly: Number(counts.ip_hourly || 0), domainDaily: Number(counts.domain_daily || 0),
        uniqueDomainsDaily: Number(counts.unique_domains_daily || 0)
      };
      if (reason) {
        await client.query('ROLLBACK');
        return { allowed: false, reason, counts: normalizedCounts };
      }

      const reservation = (await client.query(`
        INSERT INTO public.send_reservations
          (id, tenant_id, user_id, session_id, recipient_hash, recipient_domain, source_ip_hash, message_type)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        RETURNING *
      `, [input.id, tenant.id, input.userId || null, input.sessionId || null, input.recipientHash, input.recipientDomain, input.sourceIpHash || null, input.messageType])).rows[0];
      await client.query('COMMIT');
      return {
        allowed: true,
        reservation,
        counts: {
          ...normalizedCounts,
          hourly: normalizedCounts.hourly + 1,
          daily: normalizedCounts.daily + 1,
          total: normalizedCounts.total + 1,
          userHourly: normalizedCounts.userHourly + (input.userId ? 1 : 0),
          sessionHourly: normalizedCounts.sessionHourly + (input.sessionId ? 1 : 0),
          ipHourly: normalizedCounts.ipHourly + (input.sourceIpHash ? 1 : 0),
          domainDaily: normalizedCounts.domainDaily + 1,
          uniqueDomainsDaily: prospectiveUniqueDomains
        }
      };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async finalizeSendReservation(reservationId, input) {
    const result = await this.pool.query(`
      UPDATE public.send_reservations
      SET status = $2,
          provider_name = $3,
          provider_message_id = $4,
          failure_reason = $5,
          finalized_at = now()
      WHERE id = $1 AND status = 'reserved'
      RETURNING *
    `, [reservationId, input.status, input.providerName || null, input.providerMessageId || null, input.failureReason || null]);
    return result.rows[0] || null;
  }

  async recordAbuseAudit(input) {
    const result = await this.pool.query(`
      INSERT INTO public.abuse_audit_events
        (tenant_id, user_id, action, outcome, reason, source_ip_hash, recipient_hash, metadata)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb)
      RETURNING *
    `, [input.tenantId || null, input.userId || null, input.action, input.outcome, input.reason || null, input.sourceIpHash || null, input.recipientHash || null, JSON.stringify(input.metadata || {})]);
    return result.rows[0] || null;
  }

  async countRecentBlockedAttempts(tenantId, minutes = 60) {
    const result = await this.pool.query(`
      SELECT count(*)::integer AS count
      FROM public.abuse_audit_events
      WHERE tenant_id = $1 AND outcome = 'blocked'
        AND created_at >= now() - make_interval(mins => $2)
    `, [tenantId, minutes]);
    return Number(result.rows[0]?.count || 0);
  }

  async restrictTenant(tenantId, reason, metadata = {}) {
    const result = await this.pool.query(`
      UPDATE public.tenants
      SET trust_state = 'restricted', sending_hold_reason = $2, restricted_at = COALESCE(restricted_at, now()), updated_at = now()
      WHERE id = $1 AND trust_state <> 'suspended'
      RETURNING *
    `, [tenantId, String(reason || 'Sending restricted').slice(0, 500)]);
    await this.recordAbuseAudit({ tenantId, action: 'workspace-restriction', outcome: 'restricted', reason, metadata });
    return result.rows[0] || null;
  }

  async messageDeliverySummary(tenant, days = 30) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT
        count(*) FILTER (WHERE event_type IN ('sent','follow-up-sent'))::integer AS total,
        count(*) FILTER (WHERE lower(COALESCE(last_event,'')) = 'bounced')::integer AS bounced,
        count(*) FILTER (WHERE lower(COALESCE(last_event,'')) = 'complained')::integer AS complained
      FROM message_events
      WHERE created_at >= now() - make_interval(days => $1)
    `, [days]));
    return result.rows[0] || { total: 0, bounced: 0, complained: 0 };
  }

  async withTenant(tenant, fn) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(`SET LOCAL search_path TO ${quoteIdent(tenant.schema_name)}, public`);
      const result = await fn(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async getSettings(tenant) {
    const result = await this.withTenant(tenant, client => client.query('SELECT * FROM settings WHERE id = 1'));
    return result.rows[0] || null;
  }

  async updateSettings(tenant, input) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE settings
      SET business_name = COALESCE($1, business_name),
          review_url = COALESCE($2, review_url),
          follow_up_days = COALESCE($3, follow_up_days),
          template = COALESCE($4, template),
          email_theme_code = COALESCE($5, email_theme_code),
          email_logo_data = CASE WHEN $6::boolean THEN $7::bytea ELSE email_logo_data END,
          email_logo_mime = CASE WHEN $6::boolean THEN $8 ELSE email_logo_mime END,
          updated_at = now()
      WHERE id = 1
      RETURNING *
    `, [
      input.businessName ?? null, input.reviewUrl ?? null, input.followUpDays ?? null, input.template ?? null,
      input.emailThemeCode ?? null, Boolean(input.logoChanged), input.emailLogoData ?? null, input.emailLogoMime ?? null
    ]));
    return result.rows[0] || null;
  }


  async getBrandLogoBySlug(slug) {
    const tenant = await this.findTenantBySlug(slug);
    if (!tenant) return null;
    const settings = await this.getSettings(tenant);
    if (!settings?.email_logo_data || !settings?.email_logo_mime) return null;
    return { data: settings.email_logo_data, mime: settings.email_logo_mime, updatedAt: settings.updated_at };
  }

  async listCustomers(tenant, { includeArchived = false } = {}) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT * FROM customers
      WHERE ($1::boolean = true OR archived_at IS NULL)
      ORDER BY created_at DESC
    `, [includeArchived]));
    return result.rows;
  }

  async createCustomer(tenant, input) {
    const result = await this.withTenant(tenant, client => client.query(`
      INSERT INTO customers (id, name, phone, email, job, updated_by)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `, [input.id || crypto.randomUUID(), input.name, input.phone || null, input.email || null, input.job || null, input.updatedBy || null]));
    return result.rows[0];
  }

  async getCustomer(tenant, customerId, { includeArchived = false } = {}) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT * FROM customers
      WHERE id = $1 AND ($2::boolean = true OR archived_at IS NULL)
    `, [customerId, includeArchived]));
    return result.rows[0] || null;
  }

  async updateCustomer(tenant, customerId, input) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE customers
      SET name = $2,
          phone = $3,
          email = $4,
          job = $5,
          updated_by = $6,
          updated_at = now()
      WHERE id = $1 AND archived_at IS NULL
      RETURNING *
    `, [customerId, input.name, input.phone || null, input.email || null, input.job || null, input.updatedBy || null]));
    return result.rows[0] || null;
  }

  async archiveCustomer(tenant, customerId, userId) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE customers
      SET archived_at = now(), archived_by = $2, follow_up = false, updated_at = now()
      WHERE id = $1 AND archived_at IS NULL
      RETURNING *
    `, [customerId, userId || null]));
    return result.rows[0] || null;
  }

  async markCustomerSent(tenant, customerId, followUpDays = 3) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE customers
      SET status = 'Sent',
          sent_at = now(),
          initial_sent_at = COALESCE(initial_sent_at, now()),
          follow_up_due_at = now() + ($2::text || ' days')::interval,
          follow_up = true,
          updated_at = now()
      WHERE id = $1 AND archived_at IS NULL RETURNING *
    `, [customerId, followUpDays]));
    return result.rows[0] || null;
  }

  async markCustomerReviewed(tenant, customerId) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE customers SET status = 'Reviewed', reviewed_at = now(), completion_source = COALESCE(completion_source, 'manual'), follow_up = false, updated_at = now()
      WHERE id = $1 AND archived_at IS NULL RETURNING *
    `, [customerId]));
    return result.rows[0] || null;
  }

  async appendMessageEvent(tenant, event) {
    const result = await this.withTenant(tenant, client => client.query(`
      INSERT INTO message_events (
        id, customer_id, event_type, provider_name, provider_message_id, recipient, message,
        subject, html_body, text_body, from_address, cc, bcc, reply_to, tags,
        last_event, emailer_created_at, scheduled_at, emailer_payload, last_synced_at
      )
      VALUES (
        $1, $2, $3, $4, $5, $6, $7,
        $8, $9, $10, $11, $12::jsonb, $13::jsonb, $14::jsonb, $15::jsonb,
        $16, $17, $18, $19::jsonb, $20
      )
      RETURNING *
    `, [
      event.id || crypto.randomUUID(), event.customerId || null, event.eventType, event.providerName,
      event.providerMessageId || null, event.recipient || null, event.message || event.text || null,
      event.subject || null, event.html || null, event.text || event.message || null, event.from || null,
      JSON.stringify(event.cc || []), JSON.stringify(event.bcc || []), JSON.stringify(event.replyTo || []), JSON.stringify(event.tags || []),
      event.lastEvent || 'sent', event.emailerCreatedAt || null, event.scheduledAt || null,
      event.emailerPayload ? JSON.stringify(event.emailerPayload) : null, event.lastSyncedAt || null
    ]));
    return result.rows[0];
  }

  async listMessageEvents(tenant, customerId) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT * FROM message_events
      WHERE customer_id = $1
      ORDER BY created_at DESC
    `, [customerId]));
    return result.rows;
  }

  async listMessageEventsForSync(tenant, { intervalHours, retentionDays, limit }) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT * FROM message_events
      WHERE provider_message_id IS NOT NULL
        AND provider_name <> 'mock'
        AND created_at >= now() - ($2::text || ' days')::interval
        AND (
          COALESCE(last_synced_at, sync_attempted_at) IS NULL
          OR COALESCE(last_synced_at, sync_attempted_at) <= now() - ($1::text || ' hours')::interval
        )
      ORDER BY COALESCE(last_synced_at, sync_attempted_at, created_at), created_at
      LIMIT $3
    `, [intervalHours, retentionDays, limit]));
    return result.rows;
  }

  async recordMessageEventSync(tenant, messageEventId, email, payloadHash) {
    return this.withTenant(tenant, async client => {
      const payload = email.raw || {};
      const result = await client.query(`
        UPDATE message_events
        SET internet_message_id = $2,
            last_event = $3,
            emailer_created_at = $4,
            scheduled_at = $5,
            subject = COALESCE($6, subject),
            html_body = COALESCE($7, html_body),
            text_body = COALESCE($8, text_body),
            message = COALESCE($8, message),
            from_address = COALESCE($9, from_address),
            recipient = COALESCE($10, recipient),
            cc = $11::jsonb,
            bcc = $12::jsonb,
            reply_to = $13::jsonb,
            tags = $14::jsonb,
            emailer_payload = $15::jsonb,
            last_synced_at = now(),
            sync_attempted_at = now(),
            sync_error = NULL
        WHERE id = $1
        RETURNING *
      `, [
        messageEventId, email.internetMessageId || null, email.lastEvent || null, email.createdAt || null,
        email.scheduledAt || null, email.subject || null, email.html || null, email.text || null,
        email.from || null, email.to?.[0] || null, JSON.stringify(email.cc || []), JSON.stringify(email.bcc || []),
        JSON.stringify(email.replyTo || []), JSON.stringify(email.tags || []), JSON.stringify(payload)
      ]);
      await client.query(`
        INSERT INTO message_event_snapshots (message_event_id, payload_hash, last_event, payload)
        VALUES ($1, $2, $3, $4::jsonb)
        ON CONFLICT (message_event_id, payload_hash) DO NOTHING
      `, [messageEventId, payloadHash, email.lastEvent || null, JSON.stringify(payload)]);
      return result.rows[0] || null;
    });
  }

  async recordMessageEventSyncFailure(tenant, messageEventId, errorMessage) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE message_events
      SET sync_attempted_at = now(), sync_error = $2
      WHERE id = $1
      RETURNING *
    `, [messageEventId, String(errorMessage || 'Emailer sync failed').slice(0, 1000)]));
    return result.rows[0] || null;
  }

  async listTenants() {
    const result = await this.pool.query(`
      SELECT t.*, u.id AS owner_user_id, u.email AS owner_email, u.display_name AS owner_name, u.email_verified_at
      FROM public.tenants t
      JOIN public.tenant_memberships m ON m.tenant_id = t.id AND m.role = 'owner'
      JOIN public.users u ON u.id = m.user_id
      ORDER BY t.created_at
    `);
    return result.rows;
  }

  async createCheckoutRequest({ tenant, user, config, emailHash, expiresAt }) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(`SELECT pg_advisory_xact_lock(hashtext('reviewnudge-founding-25'))`);
      const currentTenant = (await client.query('SELECT * FROM public.tenants WHERE id = $1 FOR UPDATE', [tenant.id])).rows[0];
      if (!currentTenant) throw new Error('tenant not found');

      const existing = (await client.query(`
        SELECT * FROM public.checkout_requests
        WHERE tenant_id = $1 AND user_id = $2 AND completed_at IS NULL AND expires_at > now()
        ORDER BY created_at DESC LIMIT 1
      `, [tenant.id, user.id])).rows[0];
      if (existing) {
        await client.query('COMMIT');
        return existing;
      }

      await client.query('DELETE FROM public.checkout_requests WHERE completed_at IS NULL AND expires_at <= now()');
      let pricingTier = 'standard';
      if (currentTenant.pricing_tier === 'founding' && !currentTenant.founding_eligibility_lost_at) {
        pricingTier = 'founding';
      } else if (!currentTenant.pricing_tier) {
        const count = Number((await client.query(`
          SELECT
            (SELECT count(*) FROM public.tenants WHERE pricing_tier = 'founding') +
            (SELECT count(*) FROM public.checkout_requests
             WHERE pricing_tier = 'founding' AND completed_at IS NULL AND expires_at > now()) AS total
        `)).rows[0].total);
        if (count < config.billing.foundingLimit) pricingTier = 'founding';
      }
      const amountCents = pricingTier === 'founding' ? config.billing.foundingAmountCents : config.billing.standardAmountCents;
      const request = (await client.query(`
        INSERT INTO public.checkout_requests
          (id, tenant_id, user_id, email_hash, product_code, pricing_tier, amount_cents, currency, expires_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
        RETURNING *
      `, [crypto.randomUUID(), tenant.id, user.id, emailHash, config.billing.productCode, pricingTier, amountCents, config.billing.currency, expiresAt])).rows[0];
      await client.query('COMMIT');
      return request;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async claimCheckoutRequest(input) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const request = (await client.query('SELECT * FROM public.checkout_requests WHERE id = $1 FOR UPDATE', [input.checkoutRequestId])).rows[0];
      if (!request || request.completed_at || new Date(request.expires_at).getTime() <= Date.now()) {
        await client.query('ROLLBACK');
        return null;
      }
      const matches = request.tenant_id === input.tenantId && request.user_id === input.userId &&
        request.email_hash === input.emailHash && request.product_code === input.productCode &&
        Number(request.amount_cents) === Number(input.amountCents) && request.currency === input.currency;
      if (!matches) {
        await client.query('ROLLBACK');
        return null;
      }
      const updated = (await client.query(`
        UPDATE public.checkout_requests SET claimed_at = COALESCE(claimed_at, now()), updated_at = now()
        WHERE id = $1 RETURNING *
      `, [request.id])).rows[0];
      await client.query('COMMIT');
      return updated;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async applyBillingEvent(event) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const inserted = await client.query(`
        INSERT INTO public.billing_events (provider_event_id, event_type, tenant_id, checkout_request_id, payload)
        VALUES ($1,$2,$3,$4,$5::jsonb)
        ON CONFLICT (provider_event_id) DO NOTHING
        RETURNING provider_event_id
      `, [event.providerEventId, event.type, event.tenantId || null, event.checkoutRequestId || null, JSON.stringify(event)]);
      if (!inserted.rowCount) {
        await client.query('COMMIT');
        return { duplicate: true };
      }

      let checkoutRequest = null;
      if (event.checkoutRequestId) {
        checkoutRequest = (await client.query(
          'SELECT * FROM public.checkout_requests WHERE id = $1 FOR UPDATE',
          [event.checkoutRequestId]
        )).rows[0] || null;
        if (checkoutRequest && event.tenantId && checkoutRequest.tenant_id !== event.tenantId) {
          throw new Error('billing event tenant does not match checkout request');
        }
      }

      if (event.type === 'checkout.session.created' && checkoutRequest) {
        await client.query(`
          UPDATE public.checkout_requests
          SET stripe_session_id = $2, stripe_session_url = $3, updated_at = now()
          WHERE id = $1
        `, [checkoutRequest.id, event.stripeSessionId || null, event.checkoutUrl || null]);
      }

      if (event.type === 'checkout.session.expired' && checkoutRequest) {
        await client.query(`
          UPDATE public.checkout_requests
          SET expires_at = LEAST(expires_at, now()), updated_at = now()
          WHERE id = $1 AND completed_at IS NULL
        `, [checkoutRequest.id]);
      }

      const activationEvents = [
        'checkout.session.completed',
        'invoice.paid',
        'customer.subscription.created',
        'customer.subscription.updated',
        'customer.subscription.resumed'
      ];
      const tenantId = checkoutRequest?.tenant_id || event.tenantId || null;
      if (activationEvents.includes(event.type) && tenantId) {
        const status = event.type === 'invoice.paid' ? 'active' : (event.subscriptionStatus || 'active');
        const pricingTier = checkoutRequest?.pricing_tier || event.pricingTier || null;
        const amountCents = checkoutRequest ? Number(checkoutRequest.amount_cents) : (event.amountCents || null);
        const currency = checkoutRequest?.currency || event.currency || null;
        await client.query(`
          UPDATE public.tenants
          SET subscription_status = $2,
              trust_state = CASE WHEN trust_state IN ('pending','trial') THEN 'active' ELSE trust_state END,
              pricing_tier = COALESCE($3, pricing_tier),
              monthly_amount_cents = COALESCE($4, monthly_amount_cents),
              billing_currency = COALESCE($5, billing_currency),
              stripe_customer_id = COALESCE($6, stripe_customer_id),
              stripe_subscription_id = COALESCE($7, stripe_subscription_id),
              billing_updated_at = now(), updated_at = now()
          WHERE id = $1
        `, [tenantId, status, pricingTier, amountCents, currency, event.stripeCustomerId || null, event.stripeSubscriptionId || null]);
        if (checkoutRequest) {
          await client.query(
            'UPDATE public.checkout_requests SET completed_at = COALESCE(completed_at, now()), updated_at = now() WHERE id = $1',
            [checkoutRequest.id]
          );
        }
      }

      if (event.type === 'invoice.payment_failed' && tenantId) {
        await client.query(`UPDATE public.tenants SET subscription_status = 'past_due', billing_updated_at = now(), updated_at = now() WHERE id = $1`, [tenantId]);
      }

      if (event.type === 'customer.subscription.paused' && tenantId) {
        await client.query(`UPDATE public.tenants SET subscription_status = 'paused', billing_updated_at = now(), updated_at = now() WHERE id = $1`, [tenantId]);
      }

      if (event.type === 'customer.subscription.deleted' && tenantId) {
        await client.query(`
          UPDATE public.tenants
          SET subscription_status = 'canceled',
              founding_eligibility_lost_at = CASE WHEN pricing_tier = 'founding' THEN COALESCE(founding_eligibility_lost_at, now()) ELSE founding_eligibility_lost_at END,
              billing_updated_at = now(), updated_at = now()
          WHERE id = $1
        `, [tenantId]);
      }

      await client.query('COMMIT');
      return { duplicate: false };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }


  async createSlackOAuthState({ stateHash, tenantId, userId, expiresAt }) {
    await this.pool.query('DELETE FROM public.slack_oauth_states WHERE expires_at <= now() OR used_at IS NOT NULL');
    await this.pool.query(`
      INSERT INTO public.slack_oauth_states (state_hash, tenant_id, user_id, expires_at)
      VALUES ($1,$2,$3,$4)
    `, [stateHash, tenantId, userId, expiresAt]);
  }

  async consumeSlackOAuthState(stateHash) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const row = (await client.query(`
        SELECT * FROM public.slack_oauth_states
        WHERE state_hash = $1
        FOR UPDATE
      `, [stateHash])).rows[0];
      if (!row || row.used_at || new Date(row.expires_at).getTime() <= Date.now()) {
        await client.query('ROLLBACK');
        return null;
      }
      await client.query('UPDATE public.slack_oauth_states SET used_at = now() WHERE state_hash = $1', [stateHash]);
      await client.query('COMMIT');
      return row;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }

  async getSlackConnection(tenantId) {
    const result = await this.pool.query('SELECT * FROM public.slack_connections WHERE tenant_id = $1 LIMIT 1', [tenantId]);
    return result.rows[0] || null;
  }

  async upsertSlackConnection(tenantId, input) {
    const result = await this.pool.query(`
      INSERT INTO public.slack_connections (
        tenant_id, team_id, team_name, bot_user_id, app_id, scope, channel_id, channel_name,
        incoming_webhook_url_encrypted, bot_access_token_encrypted, enabled, connected_by
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,true,$11)
      ON CONFLICT (tenant_id) DO UPDATE SET
        team_id = EXCLUDED.team_id,
        team_name = EXCLUDED.team_name,
        bot_user_id = EXCLUDED.bot_user_id,
        app_id = EXCLUDED.app_id,
        scope = EXCLUDED.scope,
        channel_id = EXCLUDED.channel_id,
        channel_name = EXCLUDED.channel_name,
        incoming_webhook_url_encrypted = EXCLUDED.incoming_webhook_url_encrypted,
        bot_access_token_encrypted = EXCLUDED.bot_access_token_encrypted,
        enabled = true,
        connected_by = EXCLUDED.connected_by,
        updated_at = now()
      RETURNING *
    `, [
      tenantId, input.teamId, input.teamName || null, input.botUserId || null, input.appId || null,
      input.scope || null, input.channelId || null, input.channelName || null,
      input.incomingWebhookUrlEncrypted || null, input.botAccessTokenEncrypted || null, input.connectedBy || null
    ]);
    return result.rows[0] || null;
  }

  async disconnectSlackConnection(tenantId) {
    const result = await this.pool.query(`
      UPDATE public.slack_connections
      SET enabled = false,
          incoming_webhook_url_encrypted = NULL,
          bot_access_token_encrypted = NULL,
          updated_at = now()
      WHERE tenant_id = $1
      RETURNING *
    `, [tenantId]);
    return result.rows[0] || null;
  }

  async recordSlackNotification(tenantId, input) {
    const result = await this.pool.query(`
      INSERT INTO public.slack_notifications (tenant_id, notification_key, notification_type, provider_message_id, payload)
      VALUES ($1,$2,$3,$4,$5::jsonb)
      ON CONFLICT (tenant_id, notification_key) DO NOTHING
      RETURNING *
    `, [tenantId, input.notificationKey, input.type, input.providerMessageId || null, JSON.stringify(input.payload || {})]);
    return result.rows[0] || null;
  }


  async listInitialSendCandidates(tenant, limit = 100) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT * FROM customers
      WHERE archived_at IS NULL AND initial_sent_at IS NULL AND email IS NOT NULL AND status = 'Ready'
      ORDER BY created_at LIMIT $1
    `, [limit]));
    return result.rows;
  }

  async listDueFollowUps(tenant, limit = 100) {
    const result = await this.withTenant(tenant, client => client.query(`
      SELECT * FROM customers
      WHERE archived_at IS NULL AND follow_up = true AND follow_up_due_at <= now() AND follow_up_sent_at IS NULL
        AND reviewed_at IS NULL AND email IS NOT NULL
      ORDER BY follow_up_due_at LIMIT $1
    `, [limit]));
    return result.rows;
  }

  async markFollowUpSent(tenant, customerId) {
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE customers SET follow_up_sent_at = now(), follow_up = false, updated_at = now()
      WHERE id = $1 AND archived_at IS NULL RETURNING *
    `, [customerId]));
    return result.rows[0] || null;
  }

  async notificationExists(tenantId, notificationKey) {
    const result = await this.pool.query('SELECT 1 FROM public.tenant_notifications WHERE tenant_id = $1 AND notification_key = $2', [tenantId, notificationKey]);
    return result.rowCount > 0;
  }

  async recordNotification(tenantId, input) {
    const result = await this.pool.query(`
      INSERT INTO public.tenant_notifications (tenant_id, notification_type, notification_key, provider_name, provider_message_id)
      VALUES ($1,$2,$3,$4,$5)
      ON CONFLICT (tenant_id, notification_key) DO NOTHING RETURNING *
    `, [tenantId, input.type, input.key, input.providerName || null, input.providerMessageId || null]);
    return result.rows[0] || null;
  }

  async recordReviewProviderEvent(input) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const inserted = (await client.query(`
        INSERT INTO public.review_provider_events
          (tenant_id, provider, provider_event_id, reviewer_name, rating, comment, review_created_at, payload)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb)
        ON CONFLICT (provider, provider_event_id) DO NOTHING
        RETURNING *
      `, [input.tenantId, input.provider, input.providerEventId, input.reviewerName || null, input.rating || null, input.comment || null, input.createdAt || null, JSON.stringify(input.payload || input)])).rows[0];
      if (!inserted) {
        await client.query('COMMIT');
        return { duplicate: true };
      }
      await client.query('COMMIT');
      return { duplicate: false, event: inserted };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async applyReviewMatch(tenant, eventId, match) {
    if (!match.customer) return null;
    const status = match.outcome === 'matched' ? 'Reviewed' : 'Needs confirmation';
    const result = await this.withTenant(tenant, client => client.query(`
      UPDATE customers
      SET status = $2,
          reviewed_at = CASE WHEN $2 = 'Reviewed' THEN now() ELSE reviewed_at END,
          completion_source = CASE WHEN $2 = 'Reviewed' THEN 'provider' ELSE completion_source END,
          review_provider_event_id = $3,
          follow_up = CASE WHEN $2 = 'Reviewed' THEN false ELSE follow_up END,
          updated_at = now()
      WHERE id = $1 RETURNING *
    `, [match.customer.id, status, eventId]));
    await this.pool.query(`
      UPDATE public.review_provider_events
      SET match_outcome = $2, matched_customer_id = $3, match_score = $4
      WHERE id = $1
    `, [eventId, match.outcome, match.customer.id, match.score]);
    return result.rows[0] || null;
  }


  async findAccountByEmail(email, tenantId) {
    const result = await this.pool.query(`
      SELECT u.id AS user_id, u.email, u.display_name, t.id AS tenant_id, t.name AS tenant_name, t.slug
      FROM public.users u
      JOIN public.tenant_memberships m ON m.user_id = u.id
      JOIN public.tenants t ON t.id = m.tenant_id
      WHERE u.email = lower($1) AND t.id = $2
      LIMIT 1
    `, [email, tenantId]);
    return result.rows[0] || null;
  }

  async createPasswordResetToken({ tokenHash, userId, tenantId, expiresAt }) {
    await this.pool.query('DELETE FROM public.password_reset_tokens WHERE user_id = $1 AND tenant_id = $2', [userId, tenantId]);
    await this.pool.query(`
      INSERT INTO public.password_reset_tokens (token_hash, user_id, tenant_id, expires_at)
      VALUES ($1,$2,$3,$4)
    `, [tokenHash, userId, tenantId, expiresAt]);
  }

  async isPasswordResetTokenValid(tokenHash, tenantId = null) {
    const result = await this.pool.query(`
      SELECT EXISTS (
        SELECT 1 FROM public.password_reset_tokens
        WHERE token_hash = $1
          AND ($2::uuid IS NULL OR tenant_id = $2)
          AND used_at IS NULL
          AND expires_at > now()
      ) AS valid
    `, [tokenHash, tenantId]);
    return Boolean(result.rows[0]?.valid);
  }

  async consumePasswordResetToken(tokenHash, tenantId = null) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const row = (await client.query(`
        SELECT * FROM public.password_reset_tokens
        WHERE token_hash = $1
          AND ($2::uuid IS NULL OR tenant_id = $2)
        FOR UPDATE
      `, [tokenHash, tenantId])).rows[0];
      if (!row || row.used_at || new Date(row.expires_at).getTime() <= Date.now()) {
        await client.query('ROLLBACK');
        return null;
      }
      await client.query('UPDATE public.password_reset_tokens SET used_at = now() WHERE token_hash = $1', [tokenHash]);
      await client.query('COMMIT');
      return row;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }

  async updateUserPassword(userId, passwordHash) {
    await this.pool.query('UPDATE public.users SET password_hash = $2, updated_at = now() WHERE id = $1', [userId, passwordHash]);
    await this.pool.query('DELETE FROM public.sessions WHERE user_id = $1', [userId]);
  }

  async listPasskeys(userId, tenantId) {
    const result = await this.pool.query('SELECT * FROM public.passkeys WHERE user_id = $1 AND tenant_id = $2 ORDER BY created_at', [userId, tenantId]);
    return result.rows;
  }

  async createWebauthnChallenge({ userId, tenantId, purpose, challenge, expiresAt }) {
    await this.pool.query('DELETE FROM public.webauthn_challenges WHERE user_id = $1 AND tenant_id = $2 AND purpose = $3', [userId, tenantId, purpose]);
    await this.pool.query(`INSERT INTO public.webauthn_challenges (user_id, tenant_id, purpose, challenge, expires_at) VALUES ($1,$2,$3,$4,$5)`, [userId, tenantId, purpose, challenge, expiresAt]);
  }

  async consumeWebauthnChallenge({ userId, tenantId, purpose }) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const row = (await client.query(`
        SELECT * FROM public.webauthn_challenges
        WHERE user_id=$1 AND tenant_id=$2 AND purpose=$3 AND used_at IS NULL AND expires_at > now()
        ORDER BY created_at DESC LIMIT 1 FOR UPDATE
      `, [userId, tenantId, purpose])).rows[0];
      if (!row) { await client.query('ROLLBACK'); return null; }
      await client.query('UPDATE public.webauthn_challenges SET used_at = now() WHERE id = $1', [row.id]);
      await client.query('COMMIT');
      return row;
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  }

  async savePasskey({ credentialId, userId, tenantId, publicKey, counter, transports, deviceType, backedUp }) {
    await this.pool.query(`
      INSERT INTO public.passkeys (credential_id,user_id,tenant_id,public_key,counter,transports,device_type,backed_up)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      ON CONFLICT (credential_id) DO UPDATE SET public_key=EXCLUDED.public_key,counter=EXCLUDED.counter,transports=EXCLUDED.transports,device_type=EXCLUDED.device_type,backed_up=EXCLUDED.backed_up
    `, [credentialId,userId,tenantId,Buffer.from(publicKey),counter,transports || [],deviceType || null,Boolean(backedUp)]);
  }

  async getPasskey(credentialId, tenantId = null) {
    const result = await this.pool.query(`
      SELECT p.*, u.email, u.display_name, m.role, t.name AS tenant_name, t.slug, t.schema_name,
             t.onboarding_completed_at, t.created_at, t.trial_ends_at, t.subscription_status,
             t.pricing_tier, t.monthly_amount_cents, t.billing_currency, t.stripe_customer_id,
             t.stripe_subscription_id, t.founding_eligibility_lost_at, t.trust_state,
             t.sending_hold_reason, t.restricted_at, t.suspended_at
      FROM public.passkeys p
      JOIN public.users u ON u.id=p.user_id
      JOIN public.tenant_memberships m ON m.user_id=p.user_id AND m.tenant_id=p.tenant_id
      JOIN public.tenants t ON t.id=p.tenant_id
      WHERE p.credential_id=$1
        AND ($2::uuid IS NULL OR p.tenant_id=$2)
      LIMIT 1
    `, [credentialId, tenantId]);
    return result.rows[0] || null;
  }

  async updatePasskeyCounter(credentialId, counter) {
    await this.pool.query('UPDATE public.passkeys SET counter=$2,last_used_at=now() WHERE credential_id=$1', [credentialId, counter]);
  }

  async cleanupExpiredCheckoutRequests() {
    const result = await this.pool.query('DELETE FROM public.checkout_requests WHERE completed_at IS NULL AND expires_at <= now()');
    return result.rowCount;
  }

}
