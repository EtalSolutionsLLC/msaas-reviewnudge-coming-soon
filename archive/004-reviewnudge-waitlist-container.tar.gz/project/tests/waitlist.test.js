import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('waitlist has durable public schema and duplicate-safe storage', async () => {
  const sql = await readFile(new URL('../db/migrations/012_waitlist_signups.sql', import.meta.url), 'utf8');
  assert.match(sql, /CREATE TABLE IF NOT EXISTS public\.waitlist_signups/i);
  assert.match(sql, /email text NOT NULL/i);
  assert.match(sql, /metadata jsonb NOT NULL DEFAULT '\{\}'::jsonb/i);
  assert.match(sql, /uq_waitlist_signups_email/i);
});

test('public waitlist endpoint validates email and stores source metadata', async () => {
  const server = await readFile(new URL('../src/server.js', import.meta.url), 'utf8');
  const datastore = await readFile(new URL('../src/datastore/postgres.js', import.meta.url), 'utf8');
  assert.match(server, /pathname === '\/api\/waitlist'/);
  assert.match(server, /cleanEmail\(req\.body\?\.email\)/);
  assert.match(server, /createWaitlistSignup/);
  assert.match(server, /hashAbuseIdentifier\(clientIp\(req\)/);
  assert.match(datastore, /INSERT INTO public\.waitlist_signups/);
  assert.match(datastore, /ON CONFLICT \(email\) DO UPDATE/);
});
