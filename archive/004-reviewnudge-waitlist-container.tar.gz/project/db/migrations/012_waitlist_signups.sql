CREATE TABLE IF NOT EXISTS public.waitlist_signups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  source text NOT NULL DEFAULT 'coming-soon',
  ip_hash text,
  user_agent text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT waitlist_signups_email_not_blank CHECK (btrim(email) <> ''),
  CONSTRAINT waitlist_signups_email_lower CHECK (email = lower(email))
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_waitlist_signups_email
  ON public.waitlist_signups (email);

CREATE INDEX IF NOT EXISTS ix_waitlist_signups_created_at
  ON public.waitlist_signups (created_at DESC);
