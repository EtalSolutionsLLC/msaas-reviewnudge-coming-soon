#!/usr/bin/env bash
set -euo pipefail

compose_file="${1:-docker-compose.waitlist.yml}"
base_url="${WAITLIST_BASE_URL:-http://localhost:${WAITLIST_HTTP_PORT:-3080}}"
email="${WAITLIST_TEST_EMAIL:-container-smoke-$(date +%s)@example.test}"

if ! command -v docker >/dev/null 2>&1; then
  echo "docker is required" >&2
  exit 1
fi

docker compose --file "$compose_file" up --build --detach

for _ in $(seq 1 30); do
  if curl --fail --silent --show-error "$base_url/livez" >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

curl --fail --silent --show-error \
  --header 'Content-Type: application/json' \
  --data "{\"email\":\"${email}\",\"source\":\"container-smoke\"}" \
  "$base_url/api/waitlist" >/dev/null

echo "Waitlist container smoke test passed: ${email}"
