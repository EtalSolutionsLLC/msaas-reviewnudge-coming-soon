# Build 004 — ReviewNudge Waitlist Container

## Summary

Packaged the ReviewNudge Coming Soon waitlist slice into a standalone container review path.

## Included

- Coming Soon page wired to `POST /api/waitlist`
- PostgreSQL-backed `waitlist_signups` storage
- Standalone `docker-compose.waitlist.yml`
- Container smoke-test script
- Container usage note

## Verification

Run:

```bash
docker compose --file docker-compose.waitlist.yml up --build
./mgt-scripts/verify-waitlist-container.sh
```
