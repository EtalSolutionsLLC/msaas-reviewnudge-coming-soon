# ReviewNudge Coming Soon Static Site

Static GitHub Pages site under `www/`.

Local quick preview:

```bash
pm-serve-bash www/index.html
```

Container preview is handled by Portmason/Compose conventions:

```bash
pm-setup
```

Runtime nginx logs are persisted to:

```text
logs/runtime/
```

Viewport targeting test:

```bash
node --test tests/viewport-targeting.test.mjs
```
