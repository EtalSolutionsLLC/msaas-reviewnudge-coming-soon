// ReviewNudge Coming Soon waitlist configuration.
// Set this to the deployed Google Apps Script Web App URL.
// Example: https://script.google.com/macros/s/AKfycb.../exec
window.REVIEWNUDGE_WAITLIST_ENDPOINT = "https://script.google.com/macros/s/REPLACE_WITH_DEPLOYMENT_ID/exec";
